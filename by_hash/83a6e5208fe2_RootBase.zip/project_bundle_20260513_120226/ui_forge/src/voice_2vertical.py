import subprocess
import os
import sys

class VoiceToVertical:
    def __init__(self):
        self.report_path = "/tmp/va_report.txt"

    def listen_and_process(self):
        print("🎤 Listening for Lancy's instructions... (Say 'Assess' followed by your idea)")
        
        # Use Termux API to capture speech
        try:
            result = subprocess.run(["termux-speech-to-text"], capture_output=True, text=True)
            if result.returncode != 0:
                print("❌ Termux API Error: Ensure Termux:API app is installed.")
                return

            text = result.stdout.strip()
            print(f"👂 Captured: '{text}'")

            if text.lower().startswith("assess"):
                idea = text[len("assess"):].strip()
                print(f"🧠 Processing Idea: {idea}")
                
                # Trigger Vertical AI Report via Gemini CLI
                # Note: This assumes 'gemini-cli vertical-ai report' is a valid command
                cmd = f"gemini-cli vertical-ai report --idea '{idea}' --full > {self.report_path}"
                print(f"🚀 Executing: {cmd}")
                
                # Simulating execution for now as gemini-cli subcommands might differ
                # subprocess.run(cmd, shell=True)
                
                # Immediately trigger the Modind Executor
                executor_cmd = f"python3 ~/vertical/src/vertical_modind_executor.py {self.report_path}"
                print(f"🔗 Triggering Bridge: {executor_cmd}")
                
            elif "quit" in text.lower() or "exit" in text.lower():
                print("👋 Shutting down voice listener.")
                sys.exit(0)
            else:
                print("❓ Trigger word 'Assess' not detected. Try again.")

        except FileNotFoundError:
            print("❌ 'termux-speech-to-text' not found. Is Termux:API installed?")

if __name__ == "__main__":
    v2v = VoiceToVertical()
    while True:
        v2v.listen_and_process()
