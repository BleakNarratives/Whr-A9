import time
import field_bridge

# ANSI Color codes
RED = "\033[31m"
GOLD = "\033[33m"
DIM_WHITE = "\033[2;37m"
RESET = "\033[0m"

# Mapping sources to colors
COLORS = {
    "zeroclaw": RED,
    "jane": GOLD,
    "system": DIM_WHITE
}

def main():
    # Start watching from now to avoid dumping history
    last_timestamp = time.time()
    print(f"Starting field_watcher.py (watching since {time.strftime('%H:%M:%S')})... (Ctrl+C to exit)")
    
    try:
        while True:
            # poll(since=last_timestamp) returns [newest, ..., oldest]
            events = field_bridge.poll(since=last_timestamp)
            
            if events:
                # To print in chronological order, we reverse the list
                # events: [E_newest, ..., E_oldest] -> reversed(events): [E_oldest, ..., E_newest]
                for event in reversed(events):
                    source = event['source_layer']
                    color = COLORS.get(source, "")
                    reset = RESET if color else ""
                    
                    # Formatting the output
                    # [HH:MM:SS] SOURCE       -> TYPE           @ LOCATION
                    print(f"{color}[{event['time_str']}] {source:>16} -> {event['event_type']:<20} @ {event['location']}{reset}")
                    
                    # Update last_timestamp to the latest one seen in this batch
                    if event['timestamp'] > last_timestamp:
                        last_timestamp = event['timestamp']

            time.sleep(2)
    except KeyboardInterrupt:
        print("
Exiting field_watcher.py")

if __name__ == "__main__":
    main()
