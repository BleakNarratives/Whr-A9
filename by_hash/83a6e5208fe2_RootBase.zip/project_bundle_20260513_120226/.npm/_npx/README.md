# _npx

## Type: PaaS

## API Key Management
- Store keys in .env (DO NOT COMMIT).
