# Next Coder Handoff

Timestamp: 2026-05-12

## Active Direction

The ecosystem is becoming a local-first, auditable agentic education and lab brokerage stack:

- `~/lough_system`: event spine, client onboarding, review queue, CSV ingest, Lough exports.
- `~/Artificial-Criminal`: sandboxed adversarial AI security lab/scenario generator.
- `~/datacampus`: education runtime for students, cohorts, assignments, submissions, reviews, and sandbox vault records.
- `~/project_incubator/zeroclaw_lab_broker`: local lab task broker for zeroclaw/openclaw workers.
- `~/project_incubator`: future project stubs.

## Latest Completed Work

In `~/project_incubator/zeroclaw_lab_broker`:
- Added Lough export module.
- Added optional automatic export with `ZLB_LOUGH_EXPORT=1`.
- Added CLI export with `python -m zeroclaw_lab_broker.cli export-lough`.
- Exported current broker lifecycle records into Lough.
- Tests now pass with 9 tests.

Supported Lough events:
- `zeroclaw_broker.task.created`
- `zeroclaw_broker.task.claimed`
- `zeroclaw_broker.task.result`
- `zeroclaw_broker.task.claim_denied`

## Verification Commands

Run from `~/project_incubator/zeroclaw_lab_broker`:

```bash
python -m py_compile zeroclaw_lab_broker/*.py tests/*.py
python -m unittest discover -s tests -v
python -m zeroclaw_lab_broker.cli status
```

Run from `~/lough_system`:

```bash
python -m unittest discover -s tests -v
```

Run from `~/Artificial-Criminal`:

```bash
python -m unittest discover -s tests -v
```

Run from `~/datacampus`:

```bash
python -m unittest discover -s tests -v
```

## Next Best Landing Zone

Stay in `zeroclaw_lab_broker` and add:

1. Worker heartbeat:
   - `worker.heartbeat` record
   - CLI command
   - API endpoint
   - broker status includes stale workers

2. Task lease expiration:
   - claims have timestamps and lease duration
   - expired claims return tasks to open queue

3. Export watermarking:
   - avoid re-exporting the same broker records to Lough repeatedly
   - record `lough.exported` or maintain `lough_export_state.json`

## Boundaries

All projects remain sandboxed and education/review focused. Do not add:
- real-world exploitation,
- unauthorized scanning,
- credential theft,
- malware,
- persistence,
- exfiltration,
- evasion guidance for misuse,
- arbitrary command execution by workers.

Broker workers should receive lab tasks and return evidence. They should not execute uncontrolled commands.

