class ProximityLogic:
    """
    Implements hierarchical location matching for the LOUGH ecosystem.
    Calculates distance based on common prefix depth.
    """

    def calculate_distance(self, loc1: str, loc2: str) -> float:
        """
        Calculates the distance between two hierarchical locations.
        Distance 0.0 = exact match.
        Distance 1.0 = no common root.
        """
        if loc1 == loc2:
            return 0.0

        # Parse hierarchical locations (e.g., "tattoo.arm.wrist")
        parts1 = loc1.split('.')
        parts2 = loc2.split('.')

        # Count the length of the common prefix
        common_depth = 0
        for p1, p2 in zip(parts1, parts2):
            if p1 == p2:
                common_depth += 1
            else:
                break

        # Max depth of the two paths
        max_depth = max(len(parts1), len(parts2))

        if max_depth == 0:
            return 0.5

        # Distance Formula: 1.0 - (common_depth / max_depth)
        return 1.0 - (common_depth / max_depth)

    def is_within_threshold(self, agent_loc: str, event_loc: str, threshold: float) -> bool:
        """Determines if an agent is 'close enough' to an excitation to respond."""
        return self.calculate_distance(agent_loc, event_loc) <= threshold

if __name__ == "__main__":
    proximity = ProximityLogic()
    # Test cases
    loc_agent = "tattoo.arm.wrist"
    loc_event = "tattoo.arm"
    dist = proximity.calculate_distance(loc_agent, loc_event)
    print(f"Distance between {loc_agent} and {loc_event}: {dist:.2f}")
    assert dist <= 0.34, "Proximity calculation error!"
    print("✅ Proximity Engine verified.")
