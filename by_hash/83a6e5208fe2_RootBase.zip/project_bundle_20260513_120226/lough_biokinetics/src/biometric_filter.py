import numpy as np
from scipy.signal import butter, lfilter, iirnotch, convolve

class BiometricFilter:
    def __init__(self, sample_rate: float):
        self.sample_rate = sample_rate

        # High-pass filter (4th-order Butterworth at 70Hz)
        self.hp_cutoff = 70.0
        self.hp_b, self.hp_a = butter(4, self.hp_cutoff, btype='high', fs=self.sample_rate)

        # Band-pass filter (20Hz to 300Hz)
        self.bp_low = 20.0
        self.bp_high = 300.0
        self.bp_b, self.bp_a = butter(4, [self.bp_low, self.bp_high], btype='band', fs=self.sample_rate)

        # Notch filter (48-52Hz for power line interference)
        self.notch_freq = 50.0  # Center frequency
        self.notch_q = 30.0    # Quality factor
        self.notch_b, self.notch_a = iirnotch(self.notch_freq, self.notch_q, fs=self.sample_rate)

    def apply_filters(self, signal: np.ndarray) -> np.ndarray:
        # Apply high-pass filter
        filtered_signal = lfilter(self.hp_b, self.hp_a, signal)
        # Apply band-pass filter
        filtered_signal = lfilter(self.bp_b, self.bp_a, filtered_signal)
        # Apply notch filter
        filtered_signal = lfilter(self.notch_b, self.notch_a, filtered_signal)
        return filtered_signal

    def dilated_causal_convolution(self, imu_data: np.ndarray, kernel: np.ndarray, dilation_rate: int = 1) -> np.ndarray:
        # Ensure the kernel is 1D for simplicity in this example.
        # For more complex scenarios, kernel shape needs to match IMU channels.
        if imu_data.ndim > 1 and imu_data.shape[-1] != kernel.shape[0]:
             print("Warning: IMU data channels do not match kernel length. This implementation assumes kernel acts on each channel independently or a single-channel kernel.")

        # Create a dilated kernel
        dilated_kernel = np.zeros(len(kernel) * dilation_rate - (dilation_rate - 1))
        dilated_kernel[::dilation_rate] = kernel

        # Apply causal convolution. 'full' ensures output has size N + M - 1
        # To make it causal, we will only take the relevant part of the output
        # and ensure the kernel is flipped for convolution implementation.
        # scipy.signal.convolve already flips the kernel.
        
        # For causality, the output at time t should only depend on input up to time t.
        # 'valid' mode would crop output, 'full' includes all, 'same' centers.
        # A causal convolution using 'full' and then slicing:
        # The output length is L_imu + L_dilated_kernel - 1
        # We need to shift the output to align it causally.
        
        # Assuming single channel IMU data for simplicity here.
        # If multi-channel, this would need to be applied per channel or with a multi-channel kernel.
        
        if imu_data.ndim > 1: # Handle multi-channel IMU data
            reconstructed_signal = np.zeros(imu_data.shape)
            for i in range(imu_data.shape[1]): # Iterate over channels
                conv_output = convolve(imu_data[:, i], dilated_kernel, mode='full')
                # For causal output, we take up to the length of the original IMU data
                reconstructed_signal[:, i] = conv_output[:imu_data.shape[0]]
        else: # Single channel IMU data
            conv_output = convolve(imu_data, dilated_kernel, mode='full')
            reconstructed_signal = conv_output[:imu_data.shape[0]]

        return reconstructed_signal

# Example Usage:
if __name__ == "__main__":
    sample_rate = 1000  # Hz
    filter_chain = BiometricFilter(sample_rate)

    # Generate some dummy sEMG-like data (e.g., a sine wave with noise)
    t = np.linspace(0, 1, sample_rate, endpoint=False)
    emg_signal = np.sin(2 * np.pi * 10 * t) + 
                 0.5 * np.sin(2 * np.pi * 60 * t) + 
                 0.2 * np.random.randn(sample_rate)

    filtered_emg = filter_chain.apply_filters(emg_signal)

    print(f"Original EMG signal shape: {emg_signal.shape}")
    print(f"Filtered EMG signal shape: {filtered_emg.shape}")

    # Example IMU data (6-axis: accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z)
    # Let's say we have 100 samples of 6-axis IMU data
    imu_data = np.random.rand(100, 6) * 0.1 # Small random values

    # Example kernel for convolution - this would be learned in a real system
    # Kernel length affects how much 'past' data influences current output
    convolution_kernel = np.array([0.1, 0.3, 0.5, 0.3, 0.1])
    dilation_rate = 2

    # Reconstruct a single intent signal from IMU data using dilated causal convolution
    # For this example, let's assume we want to map IMU to a single intent signal.
    # In a real scenario, the kernel and output dimensions would be more complex.
    # Here, we will apply the convolution to each IMU axis and then sum/average for a single intent.

    # To simplify for the example, let's process one IMU channel (e.g., first acceleration axis)
    # and assume the kernel maps it to a single intent value.
    # In a real system, the kernel would be multi-dimensional or you'd have multiple kernels.
    single_imu_channel = imu_data[:, 0] # Taking just the first axis for demonstration
    reconstructed_intent_single_channel = filter_chain.dilated_causal_convolution(
        single_imu_channel, convolution_kernel, dilation_rate
    )
    print(f"Reconstructed intent signal (single channel IMU) shape: {reconstructed_intent_single_channel.shape}")
    
    # If the intent is to process all 6 channels and get a 6-channel output or a combined output
    # The dilated_causal_convolution function is updated to handle multi-dimensional IMU data
    reconstructed_intent_multi_channel = filter_chain.dilated_causal_convolution(
        imu_data, convolution_kernel, dilation_rate
    )
    print(f"Reconstructed intent signal (multi-channel IMU) shape: {reconstructed_intent_multi_channel.shape}")

