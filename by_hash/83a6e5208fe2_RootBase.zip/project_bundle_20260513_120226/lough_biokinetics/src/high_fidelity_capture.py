import cv2
import mediapipe as mp
import numpy as np
import time
import threading
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class BiokineticFrame:
    timestamp: float
    landmarks: np.ndarray  # Shape (21, 3)
    index_velocity: np.ndarray  # Shape (3,)
    index_acceleration: np.ndarray  # Shape (3,)
    thumb_velocity: np.ndarray  # Shape (3,)
    thumb_acceleration: np.ndarray  # Shape (3,)
    jitter_score: float

class HighFidelityCapture:
    def __init__(self, camera_id: int = 0):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.7
        )
        self.cap = cv2.VideoCapture(camera_id)
        self.running = False
        self.history: List[BiokineticFrame] = []
        self.window_size = 5
        self.raw_history = []  # Store raw landmarks for derivative calculation

    def _calculate_derivatives(self, current_landmarks: np.ndarray, dt: float):
        if len(self.raw_history) < 2:
            return np.zeros(3), np.zeros(3), np.zeros(3), np.zeros(3)

        # Index tip: 8, Thumb tip: 4
        idx_curr = current_landmarks[8]
        idx_prev = self.raw_history[-1][8]
        
        thumb_curr = current_landmarks[4]
        thumb_prev = self.raw_history[-1][4]

        v_idx = (idx_curr - idx_prev) / dt
        v_thumb = (thumb_curr - thumb_prev) / dt

        if len(self.raw_history) < 3:
            return v_idx, np.zeros(3), v_thumb, np.zeros(3)

        # Acceleration
        idx_prev_prev = self.raw_history[-2][8]
        v_idx_prev = (idx_prev - idx_prev_prev) / dt
        a_idx = (v_idx - v_idx_prev) / dt

        thumb_prev_prev = self.raw_history[-2][4]
        v_thumb_prev = (thumb_prev - thumb_prev_prev) / dt
        a_thumb = (v_thumb - v_thumb_prev) / dt

        return v_idx, a_idx, v_thumb, a_thumb

    def _calculate_stability(self, landmarks_window: List[np.ndarray]) -> float:
        if len(landmarks_window) < self.window_size:
            return 0.0
        # Focus on index tip jitter (Landmark 8)
        tips = np.array([lm[8] for lm in landmarks_window])
        variance = np.var(tips, axis=0)
        return float(np.mean(variance))

    def capture_loop(self):
        prev_time = time.time()
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                continue

            curr_time = time.time()
            dt = curr_time - prev_time
            
            # Convert to RGB for MediaPipe
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.hands.process(rgb_frame)

            if results.multi_hand_landmarks:
                hand_lms = results.multi_hand_landmarks[0]
                # Normalize relative to wrist (landmark 0)
                wrist = np.array([hand_lms.landmark[0].x, hand_lms.landmark[0].y, hand_lms.landmark[0].z])
                coords = np.array([[lm.x - wrist[0], lm.y - wrist[1], lm.z - wrist[2]] for lm in hand_lms.landmark])
                
                v_idx, a_idx, v_thumb, a_thumb = self._calculate_derivatives(coords, dt)
                
                self.raw_history.append(coords)
                if len(self.raw_history) > self.window_size:
                    self.raw_history.pop(0)

                jitter = self._calculate_stability(self.raw_history)
                
                bio_frame = BiokineticFrame(
                    timestamp=curr_time,
                    landmarks=coords,
                    index_velocity=v_idx,
                    index_acceleration=a_idx,
                    thumb_velocity=v_thumb,
                    thumb_acceleration=a_thumb,
                    jitter_score=jitter
                )
                self.history.append(bio_frame)

            prev_time = curr_time

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self.capture_loop)
        self.thread.start()

    def stop(self):
        self.running = False
        self.thread.join()
        self.cap.release()

    def save(self, filename: str):
        data = {
            'timestamps': np.array([f.timestamp for f in self.history]),
            'landmarks': np.array([f.landmarks for f in self.history]),
            'v_idx': np.array([f.index_velocity for f in self.history]),
            'a_idx': np.array([f.index_acceleration for f in self.history]),
            'v_thumb': np.array([f.thumb_velocity for f in self.history]),
            'a_thumb': np.array([f.thumb_acceleration for f in self.history]),
            'jitter': np.array([f.jitter_score for f in self.history])
        }
        np.savez_compressed(filename, **data)

if __name__ == "__main__":
    capture = HighFidelityCapture()
    print("Starting High-Fidelity Biokinetic Acquisition (60fps target)...")
    capture.start()
    try:
        while True:
            time.sleep(1)
            print(f"Captured frames: {len(capture.history)}", end='\r')
    except KeyboardInterrupt:
        print("\nStopping and saving...")
        capture.stop()
        capture.save("lancy_capture_raw.npz")
