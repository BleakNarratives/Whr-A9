import cv2
import mediapipe as mp
import numpy as np
import time
import os

class LoughTrajectoryExtractor:
    def __init__(self):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        self.mp_draw = mp.solutions.drawing_utils
        self.data_path = os.path.expanduser("~/lough_biokinetics/data/lancy_base.npy")

    def capture_baseline(self, duration=10):
        """Captures hand trajectory for a specified duration to create the Loughian baseline."""
        cap = cv2.VideoCapture(0)
        trajectory = []
        
        print(f"🎬 Starting biometric capture for {duration} seconds...")
        start_time = time.time()
        
        while time.time() - start_time < duration:
            success, img = cap.read()
            if not success:
                break
                
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = self.hands.process(img_rgb)
            
            if results.multi_hand_landmarks:
                frame_landmarks = []
                for hand_lms in results.multi_hand_landmarks:
                    # Extract 21 landmarks (x, y, z)
                    lms = [[lm.x, lm.y, lm.z] for lm in hand_lms.landmark]
                    frame_landmarks.append(lms)
                trajectory.append(frame_landmarks)
                
            # Visual feedback (if display available)
            # cv2.imshow("Lough Biometric Capture", img)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
        cap.release()
        
        if trajectory:
            np.save(self.data_path, np.array(trajectory, dtype=object))
            print(f"✅ Trajectory saved to {self.data_path}")
            print(f"📊 Captured {len(trajectory)} frames of bio-kinetic data.")
        else:
            print("❌ No landmarks detected during capture.")

if __name__ == "__main__":
    extractor = LoughTrajectoryExtractor()
    extractor.capture_baseline()
