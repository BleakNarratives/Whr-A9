# LOUGH Hub — Bio-Kinetic Genome Archive & FEP System

## Overview
The LOUGH Hub is a purpose-built system for **Field-Excited Programming (FEP)**. It serves as a persistent, self-healing "digital immune system" that archives embodied craft (Lancy Lough's legacy) as a bio-kinetic genome.

## Canonical Path (External)
All project documentation and artifacts are tracked in:
`/storage/ED7B-AD5A/root_2026/GRIMOIRE/`

## Architecture Components

### 1. Persistence Layer (GRIMOIRE/core)
- `boot.sh`: Self-healing startup sequence that verifies system health and service availability.
- `watchdog.sh`: `inotifywait`-based tripwire that detects file tampering and triggers automatic restoration of the home directory structure.

### 2. Execution Layer (modind_unified/)
- `field_state.sh`: Heartbeat monitor that detects system "excitations" (resource limits, errors).
- `immune_system.sh`: Autonomous sentinel that observes `field_state.json` and spawns Modind swarm agents to mitigate threats (Purge/Correction agents).
- `agent_manager.sh`: Orchestrates agent lifecycle and swarm tasks.
- `proximity_engine.py`: Spatial routing logic that determines if agents are close enough to an excitation to respond, using hierarchical path distance.

### 3. Vision Layer (vertical/)
- `vertical_modind_executor.py`: Cognitive bridge that parses Vertical AI Board reports for actionable intents and triggers the swarm via the Modind Manager.

### 4. Biometric/Input Layer
- `extract_trajectory.py`: MediaPipe-based trajectory capture for the "Loughian Genome" baseline.
- `voice_2vertical.py`: Accessibility interface allowing real-time board assessment entry.

## Deployment & Usage

### Starting the Hub
Run the boot sequence to initialize the watchdog and monitors:
`bash ~/GRIMOIRE/core/boot.sh`

### Triggering the Bridge
To process a board report and spawn autonomous agents:
`python3 ~/vertical/src/vertical_modind_executor.py /tmp/va_report.txt`

### Checking the Immune System
Review the autonomous mitigation logs:
`cat ~/modind_unified/logs/immune_system.log`

## Future Development
- **Skin as UI:** Implement the Three.js mapping of the epidermal/dermal junction.
- **Xenolang Protocol:** Integrate the opcode compiler for high-speed agent-to-agent messaging.
- **Boardroom Dashboard:** Connect the `equinex_v4.2` HTML frontend to the FastAPI `/ws` boardroom endpoint.

---
*LOUGH Hub — Future of Persistence*
