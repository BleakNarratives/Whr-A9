# Artificial-Criminal Restore Point

Timestamp: 2026-05-12
Status: Foundation complete; agentic scenario loop started.

## Snapshot

Core package:
- `artificial_criminal/models.py`: Lab, scoring, scenario, defense, and trend data models.
- `artificial_criminal/policy.py`: Safety policy checks and prohibited capability list.
- `artificial_criminal/lab_registry.py`: Lab manifest loading and validation.
- `artificial_criminal/scoring.py`: Evidence-based submission scoring.
- `artificial_criminal/scenario_factory.py`: Sandboxed adversarial scenario generation with paired defenses.
- `artificial_criminal/learning_ledger.py`: Append-only JSONL learning ledger.
- `artificial_criminal/trend_analysis.py`: Trend inference over generated scenario records.
- `artificial_criminal/campus.py`: CLI for listing, inspecting, generating scenarios, and inferring trends.

Docs:
- `README.md`: Project overview and commands.
- `docs/SAFETY_BOUNDARY.md`: Allowed and prohibited boundaries.
- `docs/ROADMAP.md`: Implementation phases.
- `docs/DATACAMPUS_INTEGRATION.md`: Proposed integration contract.
- `docs/AGENTIC_LOOP.md`: Observe, hypothesize, defend, simulate, evaluate, infer, review cycle.

Current lab:
- `labs/prompt_injection_basics.json`

Generated runtime artifact:
- `learning_ledger.jsonl`

## Verification Commands

```bash
python -m py_compile artificial_criminal/*.py tests/*.py
python -m unittest discover -s tests -v
python -m artificial_criminal.campus list-labs
python -m artificial_criminal.campus inspect prompt_injection_basics
python -m artificial_criminal.campus generate-scenario --domain prompt_injection --seed "agent trusted retrieved content over operator policy"
python -m artificial_criminal.campus infer-trends
```

Last known result:
- Compile passed.
- Unit suite passed with 8 tests.
- CLI generated a sandboxed scenario, logged it, and inferred a trend.

## Boundary

The project may generate:
- sandboxed adversarial hypotheses,
- simulated steps,
- expected signals,
- defense mappings,
- evidence requirements,
- trend inferences,
- review requirements.

The project must not generate:
- real-world exploit chains,
- credential theft paths,
- malware or persistence logic,
- evasion guidance for misuse,
- uncontrolled scanning,
- exfiltration procedures,
- target-specific operational playbooks.

## Resume Instructions

Recommended next project:
- Build `~/datacampus` as the educational runtime that owns students, cohorts, assignments, submissions, reviews, and sandbox lifecycle.

Recommended next Artificial-Criminal feature after datacampus exists:
- Add an integration adapter that exports lab manifests, generated scenario records, scoring results, and review requirements into datacampus.

