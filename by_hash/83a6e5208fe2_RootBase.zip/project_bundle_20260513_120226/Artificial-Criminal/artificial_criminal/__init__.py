"""Artificial-Criminal sandboxed adversarial AI security campus."""

__version__ = "0.1.0"

