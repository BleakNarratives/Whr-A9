"""Pattern and trend inference over generated scenarios."""

from collections import Counter

from .models import TrendInference


def infer_trends(records):
    """Infer training trends from ledger records."""
    scenario_payloads = [
        record["payload"]
        for record in records
        if record.get("record_type") == "scenario_generated"
    ]
    patterns = Counter(payload.get("pattern", "unknown") for payload in scenario_payloads)
    domains = Counter(payload.get("domain", "unknown") for payload in scenario_payloads)

    if not scenario_payloads:
        return TrendInference(
            trend_id="empty_ledger",
            summary="No scenarios have been generated yet.",
            supporting_patterns=[],
            recommended_training=["Generate at least one sandboxed scenario."],
            confidence=0.0,
            review_required=False,
        )

    top_pattern, top_pattern_count = patterns.most_common(1)[0]
    top_domain, _ = domains.most_common(1)[0]
    confidence = min(0.95, top_pattern_count / max(1, len(scenario_payloads)))
    return TrendInference(
        trend_id=f"{top_domain}_{top_pattern}_trend",
        summary=(
            f"Most generated scenarios currently emphasize {top_pattern} "
            f"inside {top_domain}."
        ),
        supporting_patterns=[pattern for pattern, _ in patterns.most_common(5)],
        recommended_training=[
            f"Add blue-team detection exercises for {top_pattern}.",
            f"Add instructor review examples for {top_domain}.",
            "Balance the corpus with adjacent patterns before drawing strong conclusions.",
        ],
        confidence=round(confidence, 3),
        review_required=True,
    )

