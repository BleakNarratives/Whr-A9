"""Command-line campus interface for Artificial-Criminal."""

import argparse
import json
from dataclasses import asdict

from .lab_registry import load_all_labs, validate_lab
from .learning_ledger import append_record, read_records
from .scenario_factory import generate_scenario, scenario_to_lab_manifest
from .trend_analysis import infer_trends


def list_labs():
    """Return a compact list of lab metadata."""
    labs = load_all_labs()
    return [
        {
            "lab_id": lab.lab_id,
            "title": lab.title,
            "domain": lab.domain,
            "difficulty": lab.difficulty,
        }
        for lab in labs.values()
    ]


def inspect_lab(lab_id):
    """Return one lab manifest and validation findings."""
    labs = load_all_labs()
    if lab_id not in labs:
        raise KeyError(f"Unknown lab: {lab_id}")
    lab = labs[lab_id]
    return {
        "manifest": asdict(lab),
        "validation_findings": validate_lab(lab),
    }


def generate_lab_scenario(domain, seed_text, difficulty="introductory"):
    """Generate, log, and return a sandboxed scenario hypothesis."""
    scenario = generate_scenario(domain, seed_text, difficulty=difficulty)
    manifest = scenario_to_lab_manifest(scenario)
    append_record("scenario_generated", asdict(scenario))
    append_record("defense_mapping_generated", manifest["fixtures"]["defenses"])
    return {
        "scenario": asdict(scenario),
        "lab_manifest": manifest,
    }


def infer_ledger_trends():
    """Infer trends from the learning ledger."""
    inference = infer_trends(read_records())
    append_record("trend_inference", asdict(inference))
    return asdict(inference)


def main():
    parser = argparse.ArgumentParser(description="Artificial-Criminal campus CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("list-labs")
    inspect_parser = subparsers.add_parser("inspect")
    inspect_parser.add_argument("lab_id")
    generate_parser = subparsers.add_parser("generate-scenario")
    generate_parser.add_argument("--domain", required=True)
    generate_parser.add_argument("--seed", required=True)
    generate_parser.add_argument("--difficulty", default="introductory")
    subparsers.add_parser("infer-trends")
    args = parser.parse_args()

    if args.command == "list-labs":
        print(json.dumps(list_labs(), indent=2, sort_keys=True))
    elif args.command == "inspect":
        print(json.dumps(inspect_lab(args.lab_id), indent=2, sort_keys=True))
    elif args.command == "generate-scenario":
        print(json.dumps(
            generate_lab_scenario(args.domain, args.seed, args.difficulty),
            indent=2,
            sort_keys=True,
        ))
    elif args.command == "infer-trends":
        print(json.dumps(infer_ledger_trends(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
