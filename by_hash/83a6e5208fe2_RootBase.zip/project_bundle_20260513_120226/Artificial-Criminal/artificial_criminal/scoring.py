"""Scoring helpers for lab submissions."""

from .models import ScoreResult


def score_submission(manifest, evidence):
    """Score a submission against manifest evidence requirements."""
    findings = []
    if not isinstance(evidence, dict):
        return ScoreResult(
            lab_id=manifest.lab_id,
            passed=False,
            score=0.0,
            findings=["Evidence must be an object."],
            review_required=True,
        )

    required = set(manifest.evidence_required)
    supplied = set(evidence.keys())
    missing = sorted(required - supplied)
    for item in missing:
        findings.append(f"Missing evidence: {item}")

    score = 1.0 if not required else (len(required - set(missing)) / len(required))
    review_required = bool(manifest.safety_boundary.review_required)
    return ScoreResult(
        lab_id=manifest.lab_id,
        passed=not missing,
        score=round(score, 3),
        findings=findings,
        review_required=review_required,
    )

