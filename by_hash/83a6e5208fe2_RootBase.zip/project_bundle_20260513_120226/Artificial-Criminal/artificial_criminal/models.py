"""Core data models for lab manifests and scoring."""

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class SafetyBoundary:
    allowed: list[str]
    prohibited: list[str]
    review_required: list[str]


@dataclass(frozen=True)
class LabManifest:
    lab_id: str
    title: str
    domain: str
    difficulty: str
    summary: str
    learning_objectives: list[str]
    blue_team_tasks: list[str]
    red_team_tasks: list[str]
    evidence_required: list[str]
    success_criteria: list[str]
    failure_criteria: list[str]
    safety_boundary: SafetyBoundary
    fixtures: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ScoreResult:
    lab_id: str
    passed: bool
    score: float
    findings: list[str]
    review_required: bool


@dataclass(frozen=True)
class DefenseControl:
    control_id: str
    name: str
    control_type: str
    description: str
    evidence: list[str]


@dataclass(frozen=True)
class ScenarioHypothesis:
    scenario_id: str
    domain: str
    pattern: str
    objective: str
    preconditions: list[str]
    simulated_steps: list[str]
    expected_signals: list[str]
    defenses: list[DefenseControl]
    review_required: bool
    safety_notes: list[str]


@dataclass(frozen=True)
class TrendInference:
    trend_id: str
    summary: str
    supporting_patterns: list[str]
    recommended_training: list[str]
    confidence: float
    review_required: bool
