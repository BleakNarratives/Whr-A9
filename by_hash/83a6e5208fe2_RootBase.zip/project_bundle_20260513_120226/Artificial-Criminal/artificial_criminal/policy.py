"""Safety policy for Artificial-Criminal labs."""

PROHIBITED_CAPABILITIES = [
    "unauthorized_targeting",
    "credential_theft",
    "malware_deployment",
    "persistence",
    "evasion_for_real_world_use",
    "uncontrolled_network_scanning",
    "data_exfiltration",
]

REVIEW_REQUIRED_DOMAINS = [
    "agentic_misuse",
    "prompt_injection",
    "tool_abuse",
    "sandbox_escape",
    "social_engineering_simulation",
]


def policy_findings(manifest):
    """Return policy findings for a lab manifest."""
    findings = []
    prohibited = set(manifest.safety_boundary.prohibited)
    missing = set(PROHIBITED_CAPABILITIES) - prohibited
    if missing:
        findings.append(
            "Safety boundary does not explicitly prohibit: "
            + ", ".join(sorted(missing))
        )

    if manifest.domain in REVIEW_REQUIRED_DOMAINS:
        if not manifest.safety_boundary.review_required:
            findings.append("Review-required domain has no review gates.")

    return findings


def is_manifest_allowed(manifest):
    """Return True when the manifest has no policy findings."""
    return not policy_findings(manifest)

