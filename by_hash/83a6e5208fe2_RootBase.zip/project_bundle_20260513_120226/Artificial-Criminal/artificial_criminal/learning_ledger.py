"""Append-only learning ledger for generated scenarios and inferences."""

import json
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LEDGER = PROJECT_ROOT / "learning_ledger.jsonl"


def append_record(record_type, payload, ledger_path=DEFAULT_LEDGER):
    """Append one structured record to the learning ledger."""
    if is_dataclass(payload):
        payload = asdict(payload)
    record = {
        "record_type": record_type,
        "created_at": time.time(),
        "payload": payload,
    }
    with Path(ledger_path).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
    return record


def read_records(ledger_path=DEFAULT_LEDGER):
    """Read all ledger records."""
    path = Path(ledger_path)
    if not path.exists():
        return []
    records = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records

