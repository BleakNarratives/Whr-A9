"""Load and validate Artificial-Criminal lab manifests."""

import json
from pathlib import Path

from .models import LabManifest, SafetyBoundary
from .policy import policy_findings

PROJECT_ROOT = Path(__file__).resolve().parents[1]
LABS_DIR = PROJECT_ROOT / "labs"


def list_lab_paths(labs_dir=LABS_DIR):
    """Return all lab manifest paths."""
    return sorted(Path(labs_dir).glob("*.json"))


def load_lab(path):
    """Load one lab manifest from JSON."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    boundary = SafetyBoundary(**data["safety_boundary"])
    return LabManifest(
        lab_id=data["lab_id"],
        title=data["title"],
        domain=data["domain"],
        difficulty=data["difficulty"],
        summary=data["summary"],
        learning_objectives=data["learning_objectives"],
        blue_team_tasks=data["blue_team_tasks"],
        red_team_tasks=data["red_team_tasks"],
        evidence_required=data["evidence_required"],
        success_criteria=data["success_criteria"],
        failure_criteria=data["failure_criteria"],
        safety_boundary=boundary,
        fixtures=data.get("fixtures", {}),
    )


def load_all_labs(labs_dir=LABS_DIR):
    """Load every lab manifest keyed by lab id."""
    labs = {}
    for path in list_lab_paths(labs_dir):
        lab = load_lab(path)
        labs[lab.lab_id] = lab
    return labs


def validate_lab(manifest):
    """Return validation findings for a manifest."""
    findings = []
    required_lists = [
        ("learning_objectives", manifest.learning_objectives),
        ("blue_team_tasks", manifest.blue_team_tasks),
        ("red_team_tasks", manifest.red_team_tasks),
        ("evidence_required", manifest.evidence_required),
        ("success_criteria", manifest.success_criteria),
        ("failure_criteria", manifest.failure_criteria),
    ]
    for name, values in required_lists:
        if not values:
            findings.append(f"{name} must not be empty")

    findings.extend(policy_findings(manifest))
    return findings

