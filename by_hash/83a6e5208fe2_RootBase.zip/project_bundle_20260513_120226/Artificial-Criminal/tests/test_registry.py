import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)

from artificial_criminal.campus import inspect_lab, list_labs
from artificial_criminal.learning_ledger import append_record, read_records
from artificial_criminal.lab_registry import load_all_labs, validate_lab
from artificial_criminal.scenario_factory import generate_scenario, scenario_to_lab_manifest
from artificial_criminal.scoring import score_submission
from artificial_criminal.trend_analysis import infer_trends


class RegistryTests(unittest.TestCase):
    def test_loads_initial_lab(self):
        labs = load_all_labs()
        self.assertIn("prompt_injection_basics", labs)

    def test_initial_lab_validates_cleanly(self):
        lab = load_all_labs()["prompt_injection_basics"]
        self.assertEqual(validate_lab(lab), [])

    def test_list_labs_returns_metadata(self):
        labs = list_labs()
        self.assertEqual(labs[0]["lab_id"], "prompt_injection_basics")

    def test_inspect_returns_manifest_and_findings(self):
        result = inspect_lab("prompt_injection_basics")
        self.assertEqual(result["manifest"]["lab_id"], "prompt_injection_basics")
        self.assertEqual(result["validation_findings"], [])

    def test_scoring_requires_evidence(self):
        lab = load_all_labs()["prompt_injection_basics"]
        result = score_submission(lab, {"annotated_transcript": "done"})
        self.assertFalse(result.passed)
        self.assertGreater(len(result.findings), 0)
        self.assertTrue(result.review_required)


class ScenarioFactoryTests(unittest.TestCase):
    def test_generate_scenario_pairs_defenses(self):
        scenario = generate_scenario("prompt_injection", "student agent ignored source labels")
        self.assertEqual(scenario.domain, "prompt_injection")
        self.assertTrue(scenario.defenses)
        self.assertTrue(scenario.review_required)
        self.assertIn("unauthorized_targeting", scenario.safety_notes[-1])

    def test_scenario_converts_to_manifest(self):
        scenario = generate_scenario("tool_abuse", "agent called broad tool without gate")
        manifest = scenario_to_lab_manifest(scenario)
        self.assertEqual(manifest["lab_id"], scenario.scenario_id)
        self.assertIn("defense_mapping", manifest["evidence_required"])
        self.assertIn("data_exfiltration", manifest["safety_boundary"]["prohibited"])

    def test_learning_ledger_and_trends(self):
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            path = tmp.name
        self.addCleanup(lambda: os.path.exists(path) and os.unlink(path))

        scenario = generate_scenario("prompt_injection", "trend seed")
        append_record("scenario_generated", scenario, ledger_path=path)
        records = read_records(ledger_path=path)
        inference = infer_trends(records)

        self.assertEqual(len(records), 1)
        self.assertIn("prompt_injection", inference.trend_id)
        self.assertTrue(inference.review_required)


if __name__ == "__main__":
    unittest.main()
