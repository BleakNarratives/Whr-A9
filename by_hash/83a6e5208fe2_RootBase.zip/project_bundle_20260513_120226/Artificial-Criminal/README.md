# Artificial-Criminal

Artificial-Criminal is a sandboxed adversarial AI security training campus. It is designed to work with a larger agentic codebase ecosystem and a separate `datacampus` environment.

The purpose is to train blue-team and red-team reasoning against malformed, exploited, or unsafe AI-agent behavior in controlled labs. It is not a real-world exploitation framework and should not contain malware, credential theft, persistence tooling, unauthorized scanning, or uncontrolled agentic attack capability.

## Operating Principles

- All exercises run in authorized sandboxes.
- Labs teach adversarial thinking through simulation, fixtures, traces, and contained mock targets.
- Blue-team work emphasizes detection, containment, audit, recovery, and governance.
- Red-team work is constrained to lab assets and produces reviewable evidence, not deployable harm.
- Every lab has a manifest, scope, success criteria, failure criteria, and safety boundary.
- No static echo-output demos. Lab results should derive from state, inputs, fixtures, evaluators, or simulations.
- No emojis in code or operational documents.

## Initial Architecture

```text
Artificial-Criminal/
  artificial_criminal/
    __init__.py
    campus.py
    lab_registry.py
    models.py
    policy.py
    scoring.py
  docs/
    SAFETY_BOUNDARY.md
    ROADMAP.md
    DATACAMPUS_INTEGRATION.md
  labs/
    prompt_injection_basics.json
  tests/
    test_registry.py
```

## First Commands

```bash
python -m py_compile artificial_criminal/*.py tests/*.py
python -m unittest discover -s tests -v
python -m artificial_criminal.campus list-labs
python -m artificial_criminal.campus inspect prompt_injection_basics
```

## Integration Direction

`datacampus` should provide the educational runtime:
- student identities
- cohorts
- progression tracking
- sandbox allocation
- lab submissions
- instructor review

Artificial-Criminal should provide:
- lab manifests
- safety policy
- adversarial scenario definitions
- blue/red learning objectives
- scoring rubrics
- evidence schemas
- review gates

## Agentic Scenario Loop

The scenario factory can generate sandboxed adversarial hypotheses and paired defensive controls:

```bash
python -m artificial_criminal.campus generate-scenario \
  --domain prompt_injection \
  --seed "agent trusted retrieved content over operator policy"
```

The generated scenario is logged to `learning_ledger.jsonl`. Trend inference can summarize recurring training needs:

```bash
python -m artificial_criminal.campus infer-trends
```

The generated material is intentionally lab-bound:
- It uses fixtures, mocks, and simulated steps.
- It creates defense mappings at the same time as adversarial hypotheses.
- It requires review for red-team outputs and generated scenarios.
- It blocks real-world targeting, credential theft, malware, persistence, evasion, uncontrolled scanning, and exfiltration.
