# Roadmap

## Phase 0 - Foundation

Implemented:
- Project skeleton.
- Lab manifest model.
- Safety policy checks.
- Lab registry.
- Basic scoring helper.
- Campus CLI.
- First safe lab manifest.
- Agentic scenario factory for sandboxed adversarial hypotheses.
- Paired defense-control generation.
- Append-only learning ledger.
- Trend inference over generated scenarios.

Exit criteria:
- Compile passes.
- Unit tests pass.
- First lab can be listed and inspected.

## Phase 1 - Datacampus Contract

Goal: define the boundary between `datacampus` and Artificial-Criminal.

Tasks:
- Define student, cohort, lab assignment, submission, and review schemas.
- Define how datacampus launches or references lab sandboxes.
- Define how grades, findings, and review status are returned.
- Define audit events that should be sent to Lough System.

## Phase 2 - Lab Runtime

Goal: run serious labs without real-world harm.

Tasks:
- Add fixture loader.
- Add transcript evaluator.
- Add mock tool-call simulator.
- Add submission storage.
- Add instructor review state.
- Persist generated scenario manifests when approved.
- Add Lough export for generated scenario and review events.

## Phase 3 - Blue/Red Training Tracks

Goal: build curriculum depth.

Tracks:
- Prompt injection and tool misuse.
- Agent memory poisoning.
- Malformed plugin/package behavior in mocks.
- Sandbox boundary testing.
- Defensive telemetry and incident response.
- Governance and policy enforcement.

## Phase 4 - World-Class Evaluation

Goal: make outputs measurable and auditable.

Tasks:
- Add rubric-based scoring.
- Add regression fixtures.
- Add adversarial scenario versioning.
- Add Lough event export.
- Add instructor dashboard or datacampus integration endpoints.

## Scenario Generation Boundary

Generated adversarial material must remain:
- abstract enough to avoid real-world exploitation steps,
- tied to a fixture or mock target,
- paired with defensive controls,
- logged for review,
- blocked from execution outside datacampus or an approved sandbox.
