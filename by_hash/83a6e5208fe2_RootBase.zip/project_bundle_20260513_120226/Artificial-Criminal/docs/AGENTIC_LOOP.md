# Agentic Loop

Artificial-Criminal uses an agentic loop for training design, not uncontrolled operations.

## Loop Stages

1. Observe
   - Read lab results, failed submissions, review notes, and generated scenario records.

2. Hypothesize
   - Generate a sandboxed adversarial pattern hypothesis.
   - Keep the hypothesis abstract and fixture-bound.

3. Defend
   - Generate paired prevention, detection, approval, or recovery controls.
   - Define evidence each control requires.

4. Simulate
   - Run only against fixtures, mock transcripts, or mock tool calls.
   - Do not target real systems.

5. Evaluate
   - Score evidence.
   - Identify missing controls.
   - Mark review-required outputs.

6. Infer
   - Aggregate scenario and submission patterns.
   - Recommend next training modules.

7. Review
   - Human or instructor review approves, rejects, or revises generated scenarios.

## Planning Output

Planning recommendations should include:
- trend summary,
- confidence,
- supporting patterns,
- defensive training recommendation,
- review requirement,
- safety notes.

Planning recommendations should not include:
- real-world target lists,
- credential acquisition instructions,
- malware or persistence instructions,
- evasion guidance for misuse,
- uncontrolled scanning instructions,
- exfiltration instructions.
