# Datacampus Integration

Datacampus should own education workflow. Artificial-Criminal should own adversarial AI security lab definitions and evaluation.

## Datacampus Owns

- Users.
- Cohorts.
- Enrollment.
- Instructor roles.
- Assignment scheduling.
- Progression.
- Submission storage, unless delegated.

## Artificial-Criminal Owns

- Lab manifests.
- Safety boundaries.
- Scenario fixtures.
- Scoring rubrics.
- Policy checks.
- Review requirements.
- Generated sandbox scenario hypotheses.
- Defense-control mappings.
- Trend inferences over lab outcomes.

## Proposed API Contract

Future endpoints:
- `GET /labs`
- `GET /labs/<lab_id>`
- `POST /assignments`
- `POST /submissions`
- `POST /submissions/<id>/review`

Every submission should include:
- `student_id`
- `cohort_id`
- `lab_id`
- `evidence`
- `created_at`
- `sandbox_id`
- `attestation`

Every result should include:
- `score`
- `passed`
- `findings`
- `review_required`
- `policy_findings`

## Agentic Training Events

Future datacampus events:
- `scenario.generated`
- `defense_mapping.generated`
- `submission.scored`
- `trend.inferred`
- `review.required`
- `review.completed`

These events should be exportable to Lough System once the interface is ready.
