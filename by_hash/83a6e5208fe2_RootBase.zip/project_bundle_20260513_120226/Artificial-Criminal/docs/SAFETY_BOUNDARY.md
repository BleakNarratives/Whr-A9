# Safety Boundary

Artificial-Criminal is for authorized education, simulation, and defensive research.

Allowed:
- Simulated adversarial AI behavior.
- Transcript analysis.
- Mock target labs.
- Defensive detection logic.
- Policy and governance review.
- Instructor-reviewed red-team reasoning within a lab manifest.

Prohibited:
- Unauthorized targeting.
- Credential theft.
- Malware deployment.
- Persistence.
- Evasion guidance for real-world misuse.
- Uncontrolled network scanning.
- Data exfiltration.
- Agentic actions against systems outside the assigned sandbox.

Required controls:
- Every lab must have a manifest.
- Every lab must state allowed and prohibited actions.
- Every lab must define evidence required for scoring.
- Every red-team output must be reviewable by a human.
- Labs that resemble real abuse patterns must use fixtures, mocks, or isolated sandboxes.

