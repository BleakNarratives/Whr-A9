#!/usr/bin/env python3
"""demo_defense_pitch.py — One-command demo for defense pitch meetings."""
import json, sys
from pathlib import Path
INTEGRATION_DIR = Path(__file__).resolve().parent
if str(INTEGRATION_DIR) not in sys.path:
    sys.path.insert(0, str(INTEGRATION_DIR))
from lough_pipeline import run_demo, STAGE_LOG

def generate_pitch_summary(summary):
    return f"""
{'='*60}
  AUTONOMOUS ADVERSARIAL TRAINING PIPELINE — DEMONSTRATION
{'='*60}

SYSTEM: Lough Ecosystem (Local-First, Auditable Agentic Stack)

FLOW:
  1. SCENARIO GENERATION
     -> AI-generated sandboxed adversarial hypothesis
     -> Paired defensive controls auto-scaffolded at creation
     -> Domain: prompt_injection

  2. EDUCATIONAL RUNTIME (Datacampus)
     -> Assignment: {summary['assignment_id']}
     -> Sandbox: {summary['sandbox_id']}

  3. WORKER BROKERAGE (Zeroclaw)
     -> Worker: {summary['worker_id']}
     -> Task created with capability matching
     -> Claim -> Result flow completed

  4. EVIDENCE & REVIEW
     -> Submission: {summary['submission_id']}
     -> Instructor review: PASSED

  5. AUDIT SPINE (Lough)
     -> {summary['stages']} lifecycle events exported
     -> JSONL records available for inspection

CAPABILITIES:
  ✓ Autonomous scenario generation with paired defenses
  ✓ Capability-matched task brokerage
  ✓ Sandbox vault lifecycle tracking
  ✓ Human-in-the-loop review gates
  ✓ Full audit trail with event envelope metadata
  ✓ Local-first, no cloud dependency

DEFENSE APPLICATION:
  -> Red-team AI simulation without real-world harm
  -> Human reasoning failure pattern cataloguing
  -> Adversarial vulnerability discovery in controlled labs
  -> Exportable evidence for compliance and governance

NEXT PHASE (with funding):
  -> Expand scenario domains (tool_abuse, sandbox_escape, memory_poisoning)
  -> Add regression fixtures and adversarial scenario versioning
  -> Build instructor dashboard with real-time review queue
  -> Integrate with existing DoD training infrastructure

{'='*60}
"""

def main():
    print("[DEMO] Starting defense pitch pipeline...\n")
    summary = run_demo()
    print(generate_pitch_summary(summary))
    summary_path = Path("demo_summary.json")
    with open(summary_path, "w") as f:
        json.dump({"summary": summary, "stage_log": STAGE_LOG}, f, indent=2, default=str)
    print(f"\n[SAVE] Machine-readable summary: {summary_path}")
    return summary

if __name__ == "__main__":
    main()
