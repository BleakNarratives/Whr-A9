"""
lough_pipeline.py
Integration layer for the Lough ecosystem.
Wires Artificial-Criminal scenario generation → datacampus assignment →
zeroclaw broker task → claim → result → Lough export.
"""

import json
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

HOME = Path("/data/data/com.termux/files/home")
LOUGH_PATH = HOME / "lough_system"
AC_PATH = HOME / "Artificial-Criminal"
DC_PATH = HOME / "datacampus"
BROKER_PATH = HOME / "project_incubator" / "zeroclaw_lab_broker"

for p in [LOUGH_PATH, AC_PATH, DC_PATH, BROKER_PATH]:
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

STAGE_LOG = []

def _stage(name, payload):
    record = {"stage": name, "timestamp": time.time(), "payload": payload}
    STAGE_LOG.append(record)
    print(f"[PIPELINE] {name}: {json.dumps(payload, default=str)[:120]}")
    return record

def _import_ac():
    from artificial_criminal.scenario_factory import generate_scenario, scenario_to_lab_manifest
    from artificial_criminal.learning_ledger import append_record as ac_append
    return generate_scenario, scenario_to_lab_manifest, ac_append

def _import_dc():
    from datacampus.runtime import create_assignment, create_sandbox_vault, submit_evidence, review_submission, create_student, create_cohort
    from datacampus.store import append_record as dc_append
    return create_assignment, create_sandbox_vault, submit_evidence, review_submission, create_student, create_cohort, dc_append

def _import_broker():
    from zeroclaw_lab_broker.broker import create_task, claim_task, submit_result, register_worker
    return create_task, claim_task, submit_result, register_worker

def _import_lough():
    import field_bridge
    return field_bridge

def stage_generate_scenario(domain, seed_text, difficulty="introductory"):
    generate_scenario, scenario_to_lab_manifest, ac_append = _import_ac()
    scenario = generate_scenario(domain, seed_text, difficulty=difficulty)
    manifest = scenario_to_lab_manifest(scenario)
    ac_append("scenario_generated", asdict(scenario))
    _stage("scenario_generated", {"scenario_id": scenario.scenario_id, "domain": domain})
    return scenario, manifest

def stage_create_assignment(cohort_id, lab_id, source_project="Artificial-Criminal"):
    create_assignment, _, _, _, _, _, dc_append = _import_dc()
    assignment = create_assignment(cohort_id, lab_id, source_project=source_project)
    _stage("assignment_created", {"assignment_id": assignment.assignment_id})
    return assignment

def stage_create_sandbox(assignment_id):
    _, create_sandbox_vault, _, _, _, _, _ = _import_dc()
    vault = create_sandbox_vault(assignment_id)
    _stage("sandbox_created", {"sandbox_id": vault.sandbox_id, "state": vault.state})
    return vault

def stage_register_worker(name, capabilities):
    _, _, _, register_worker = _import_broker()
    worker = register_worker(name, capabilities)
    _stage("worker_registered", {"worker_id": worker.worker_id, "capabilities": capabilities})
    return worker

def stage_create_task(assignment_id, lab_id, required_capabilities):
    create_task, _, _, _ = _import_broker()
    task = create_task(assignment_id, lab_id, required_capabilities)
    _stage("task_created", {"task_id": task.task_id, "lab_id": lab_id})
    return task

def stage_claim_task(task_id, worker_id):
    _, claim_task, _, _ = _import_broker()
    claim = claim_task(task_id, worker_id)
    _stage("task_claimed", {"task_id": task_id, "worker_id": worker_id, "claim_id": claim.claim_id})
    return claim

def stage_submit_result(task_id, worker_id, result_data):
    _, _, submit_result, _ = _import_broker()
    result = submit_result(task_id, worker_id, result_data)
    _stage("result_submitted", {"task_id": task_id, "worker_id": worker_id, "result_id": result.result_id})
    return result

def stage_submit_evidence(assignment_id, student_id, evidence, sandbox_id=None):
    _, _, submit_evidence, _, _, _, _ = _import_dc()
    submission = submit_evidence(assignment_id, student_id, evidence, sandbox_id=sandbox_id)
    _stage("evidence_submitted", {"submission_id": submission.submission_id, "assignment_id": assignment_id})
    return submission

def stage_review(submission_id, reviewer, status, notes=""):
    _, _, _, review_submission, _, _, _ = _import_dc()
    review = review_submission(submission_id, reviewer, status, notes=notes)
    _stage("review_completed", {"review_id": review.review_id, "status": status})
    return review

def stage_export_to_lough(record_type, payload):
    field_bridge = _import_lough()
    event_type_map = {
        "scenario_generated": "zeroclaw_broker.task.created",
        "assignment_created": "datacampus.assignment.created",
        "task_created": "zeroclaw_broker.task.created",
        "task_claimed": "zeroclaw_broker.task.claimed",
        "result_submitted": "zeroclaw_broker.task.result",
        "evidence_submitted": "datacampus.submission.created",
        "review_completed": "datacampus.review.completed",
    }
    event_type = event_type_map.get(record_type, "system.pipeline.stage")
    field_bridge.emit(event_type=event_type, location="lough_pipeline", source="lough_pipeline", payload=payload)
    _stage("lough_exported", {"record_type": record_type, "event_type": event_type})

def run_demo():
    print("=" * 60)
    print("LOUGH PIPELINE DEMO -- Defense Pitch Integration")
    print("=" * 60)

    scenario, manifest = stage_generate_scenario("prompt_injection", "agent trusted retrieved content over operator policy", "introductory")
    stage_export_to_lough("scenario_generated", {"scenario_id": scenario.scenario_id})

    _ , _ , _ , _ , create_student, create_cohort, _ = _import_dc()
    student = create_student("Demo Student")
    cohort = create_cohort("Demo Cohort", [student.student_id])

    assignment = stage_create_assignment(cohort.cohort_id, scenario.scenario_id)
    stage_export_to_lough("assignment_created", {"assignment_id": assignment.assignment_id})

    vault = stage_create_sandbox(assignment.assignment_id)
    worker = stage_register_worker("openclaw-demo", ["fixture_read", "mock_simulation", "evidence_submit"])
    task = stage_create_task(assignment.assignment_id, scenario.scenario_id, ["fixture_read", "mock_simulation"])
    stage_export_to_lough("task_created", {"task_id": task.task_id})

    claim = stage_claim_task(task.task_id, worker.worker_id)
    stage_export_to_lough("task_claimed", {"task_id": task.task_id, "worker_id": worker.worker_id})

    evidence = {"scenario_trace": "student identified untrusted source", "defense_mapping": "instruction_boundary_check mapped", "agent_decision_log": "agent refused tool call without approval"}
    result = stage_submit_result(task.task_id, worker.worker_id, {"status": "completed", "findings": evidence})
    stage_export_to_lough("result_submitted", {"task_id": task.task_id, "result_id": result.result_id})

    submission = stage_submit_evidence(assignment.assignment_id, student.student_id, evidence, sandbox_id=vault.sandbox_id)
    stage_export_to_lough("evidence_submitted", {"submission_id": submission.submission_id})

    review = stage_review(submission.submission_id, "instructor", "passed", "All defensive controls mapped correctly. Sandbox-bound.")
    stage_export_to_lough("review_completed", {"review_id": review.review_id, "status": "passed"})

    print("\n" + "=" * 60)
    print("DEMO COMPLETE")
    print("=" * 60)
    summary = {"scenario_id": scenario.scenario_id, "assignment_id": assignment.assignment_id, "sandbox_id": vault.sandbox_id, "worker_id": worker.worker_id, "task_id": task.task_id, "submission_id": submission.submission_id, "review_id": review.review_id, "stages": len(STAGE_LOG)}
    print(json.dumps(summary, indent=2, sort_keys=True))
    return summary

if __name__ == "__main__":
    run_demo()
