"""test_pipeline.py — Unit tests for Lough integration."""
import unittest, sys
from pathlib import Path
INTEGRATION_DIR = Path(__file__).resolve().parent
if str(INTEGRATION_DIR) not in sys.path:
    sys.path.insert(0, str(INTEGRATION_DIR))

class PipelineImportTests(unittest.TestCase):
    def test_module_imports(self):
        import lough_pipeline
        self.assertTrue(hasattr(lough_pipeline, "run_demo"))
        self.assertTrue(hasattr(lough_pipeline, "STAGE_LOG"))

    def test_stage_functions_exist(self):
        import lough_pipeline as lp
        for name in ["stage_generate_scenario", "stage_create_assignment", "stage_create_sandbox", "stage_register_worker", "stage_create_task", "stage_claim_task", "stage_submit_result", "stage_submit_evidence", "stage_review", "stage_export_to_lough"]:
            self.assertTrue(hasattr(lp, name), f"Missing: {name}")

    def test_stage_log_is_list(self):
        import lough_pipeline as lp
        self.assertIsInstance(lp.STAGE_LOG, list)

class PipelineMockTests(unittest.TestCase):
    def test_stage_log_append(self):
        import lough_pipeline as lp
        initial = len(lp.STAGE_LOG)
        lp._stage("test", {"foo": "bar"})
        self.assertEqual(len(lp.STAGE_LOG), initial + 1)
        self.assertEqual(lp.STAGE_LOG[-1]["stage"], "test")

if __name__ == "__main__":
    unittest.main()
