# Zeroclaw Lab Broker

Purpose:
Broker safe, sandboxed lab jobs between datacampus, Artificial-Criminal, and local agent swarms.

Useful output:
- queue of lab tasks,
- sandbox allocation records,
- completion and failure events,
- reviewer handoff bundles.

Potential revenue path:
- managed training labs,
- instructor-reviewed assessment packages,
- internal security upskilling for small teams.

First build:
- JSONL task queue.
- Worker capability registry.
- Review-required routing.
- Lough export.

Current commands:

```bash
python -m py_compile zeroclaw_lab_broker/*.py tests/*.py
python -m unittest discover -s tests -v
python -m zeroclaw_lab_broker.cli register-worker --name openclaw-local --capability fixture_read --capability mock_simulation --capability evidence_submit
python -m zeroclaw_lab_broker.cli create-task --assignment-id assignment_1 --lab-id prompt_injection_basics --capability fixture_read --capability mock_simulation
python -m zeroclaw_lab_broker.cli open-tasks
python -m zeroclaw_lab_broker.cli smoke-claim-result
python -m zeroclaw_lab_broker.cli export-lough
```

Local API:

```bash
export ZLB_API_TOKEN="replace-with-long-random-token"
python -m zeroclaw_lab_broker.server
```

Endpoints:
- `GET /status`
- `GET /workers`
- `POST /workers`
- `GET /tasks`
- `POST /tasks`
- `POST /claims`
- `POST /results`
- `GET /records`

Optional automatic Lough export:

```bash
export ZLB_LOUGH_EXPORT=1
```

When enabled, supported broker lifecycle records are mirrored into Lough:
- `zeroclaw_broker.task.created`
- `zeroclaw_broker.task.claimed`
- `zeroclaw_broker.task.result`
- `zeroclaw_broker.task.claim_denied`

Boundary:
- Lab jobs only.
- No real-world target execution.
- No uncontrolled autonomous operations.
