# Zeroclaw Lab Broker Restore Point

Timestamp: 2026-05-12
Status: Local broker skeleton implemented.

## Snapshot

Core package:
- `zeroclaw_lab_broker/models.py`: Worker, lab task, claim, and result models.
- `zeroclaw_lab_broker/store.py`: Append-only JSONL store.
- `zeroclaw_lab_broker/ids.py`: Deterministic ID helper.
- `zeroclaw_lab_broker/policy.py`: Capability and prohibited-action checks.
- `zeroclaw_lab_broker/broker.py`: Worker registry, task creation, open-task listing, claiming, result submission, datacampus import, and status.
- `zeroclaw_lab_broker/cli.py`: Local CLI.
- `zeroclaw_lab_broker/server.py`: Local HTTP API with token guard.
- `zeroclaw_lab_broker/lough_export.py`: Lough lifecycle event exporter.

Docs:
- `README.md`
- `docs/ROADMAP.md`

Tests:
- `tests/test_broker.py`

Runtime artifact:
- `broker_records.jsonl` may exist after CLI smoke tests.

## Verification Commands

```bash
python -m py_compile zeroclaw_lab_broker/*.py tests/*.py
python -m unittest discover -s tests -v
python -m zeroclaw_lab_broker.cli register-worker --name openclaw-local --capability fixture_read --capability mock_simulation --capability evidence_submit
python -m zeroclaw_lab_broker.cli create-task --assignment-id assignment_smoke --lab-id prompt_injection_basics --capability fixture_read --capability mock_simulation
python -m zeroclaw_lab_broker.cli open-tasks
python -m zeroclaw_lab_broker.cli smoke-claim-result
python -m zeroclaw_lab_broker.cli export-lough
python -m zeroclaw_lab_broker.cli status
```

Last known result:
- Compile passed.
- Unit suite passed with 9 tests.
- CLI created workers and tasks.
- CLI smoke claim/result completed.
- `export-lough` pushed current task lifecycle records to Lough.

## Boundary

The broker assigns and records lab work. It does not execute arbitrary commands, run attack tools, or orchestrate real-world operations.

## Resume Instructions

Recommended next feature:
- Add worker heartbeat and task lease expiration.
- Add Lough export deduplication or export watermarking.
