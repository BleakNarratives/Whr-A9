import os
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)

from zeroclaw_lab_broker import broker, lough_export, server, store


class BrokerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False)
        self.tmp.close()
        self.old_store = store.DEFAULT_STORE
        store.DEFAULT_STORE = self.tmp.name

    def tearDown(self):
        store.DEFAULT_STORE = self.old_store
        try:
            os.unlink(self.tmp.name)
        except FileNotFoundError:
            pass

    def test_worker_claim_result_flow(self):
        worker = broker.register_worker(
            "openclaw-local",
            ["fixture_read", "mock_simulation", "evidence_submit"],
        )
        task = broker.create_task(
            "assignment_1",
            "prompt_injection_basics",
            ["fixture_read", "mock_simulation"],
        )
        claim = broker.claim_task(task.task_id, worker.worker_id)
        result = broker.submit_result(
            task.task_id,
            worker.worker_id,
            "completed",
            {"summary": "fixture analyzed"},
        )

        self.assertEqual(claim.status, "claimed")
        self.assertTrue(result.review_required)
        self.assertEqual(broker.broker_status()["results"], 1)

    def test_prohibited_capability_denied(self):
        worker = broker.register_worker("worker", ["fixture_read"])
        task = broker.create_task(
            "assignment_2",
            "unsafe_lab",
            ["credential_theft"],
        )
        claim = broker.claim_task(task.task_id, worker.worker_id)
        self.assertEqual(claim["status"], "denied")
        self.assertTrue(claim["findings"])

    def test_import_datacampus_assignments(self):
        records = [
            {
                "record_type": "assignment.created",
                "payload": {
                    "assignment_id": "assignment_1",
                    "lab_id": "prompt_injection_basics",
                    "review_required": True,
                    "source_project": "Artificial-Criminal",
                },
            }
        ]
        tasks = broker.import_datacampus_assignments(records)
        self.assertEqual(len(tasks), 1)
        self.assertEqual(tasks[0].source, "datacampus")

    def test_lough_export_maps_supported_record(self):
        record = {
            "record_type": "task.created",
            "created_at": 1.0,
            "payload": {
                "task_id": "task_1",
                "lab_id": "lab_1",
            },
        }
        with patch.object(lough_export, "_load_field_bridge") as load_bridge:
            fake_bridge = load_bridge.return_value
            result = lough_export.export_record(record)

        self.assertTrue(result["exported"])
        fake_bridge.emit.assert_called_once()
        self.assertEqual(
            fake_bridge.emit.call_args.kwargs["event_type"],
            "zeroclaw_broker.task.created",
        )

    def test_auto_lough_export_when_enabled(self):
        with patch.dict(os.environ, {"ZLB_LOUGH_EXPORT": "1"}):
            with patch.object(broker.lough_export, "export_record") as export_record:
                broker.create_task("assignment_1", "lab_1", ["fixture_read"])

        export_record.assert_called_once()

    def test_smoke_claim_result(self):
        broker.register_worker(
            "openclaw-local",
            ["fixture_read", "mock_simulation", "evidence_submit"],
        )
        broker.create_task(
            "assignment_1",
            "prompt_injection_basics",
            ["fixture_read"],
        )
        result = broker.smoke_claim_result()
        self.assertIsNotNone(result["result"])
        self.assertEqual(broker.broker_status()["results"], 1)


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False)
        self.tmp.close()
        self.old_store = store.DEFAULT_STORE
        self.old_token = server.API_TOKEN
        self.old_allow_remote = server.ALLOW_REMOTE
        store.DEFAULT_STORE = self.tmp.name
        server.API_TOKEN = None
        server.ALLOW_REMOTE = False
        self.client = server.app.test_client()

    def tearDown(self):
        store.DEFAULT_STORE = self.old_store
        server.API_TOKEN = self.old_token
        server.ALLOW_REMOTE = self.old_allow_remote
        try:
            os.unlink(self.tmp.name)
        except FileNotFoundError:
            pass

    def test_remote_rejected_without_token(self):
        response = self.client.get(
            "/status",
            environ_overrides={"REMOTE_ADDR": "203.0.113.10"},
        )
        self.assertEqual(response.status_code, 401)

    def test_token_allows_remote(self):
        server.API_TOKEN = "secret"
        response = self.client.get(
            "/status",
            headers={"X-ZLB-Token": "secret"},
            environ_overrides={"REMOTE_ADDR": "203.0.113.10"},
        )
        self.assertEqual(response.status_code, 200)

    def test_api_worker_task_claim_result_flow(self):
        worker_response = self.client.post(
            "/workers",
            json={
                "name": "openclaw-local",
                "capabilities": ["fixture_read", "mock_simulation"],
            },
        )
        self.assertEqual(worker_response.status_code, 201)
        worker_id = worker_response.get_json()["worker_id"]

        task_response = self.client.post(
            "/tasks",
            json={
                "assignment_id": "assignment_1",
                "lab_id": "prompt_injection_basics",
                "required_capabilities": ["fixture_read"],
            },
        )
        self.assertEqual(task_response.status_code, 201)
        task_id = task_response.get_json()["task_id"]

        claim_response = self.client.post(
            "/claims",
            json={"task_id": task_id, "worker_id": worker_id},
        )
        self.assertEqual(claim_response.status_code, 201)

        result_response = self.client.post(
            "/results",
            json={
                "task_id": task_id,
                "worker_id": worker_id,
                "status": "completed",
                "evidence": {"summary": "done"},
            },
        )
        self.assertEqual(result_response.status_code, 201)
        self.assertTrue(result_response.get_json()["review_required"])


if __name__ == "__main__":
    unittest.main()
