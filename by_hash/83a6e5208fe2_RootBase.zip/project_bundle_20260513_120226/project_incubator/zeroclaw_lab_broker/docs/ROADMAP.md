# Zeroclaw Lab Broker Roadmap

## Phase 0 - Local Broker

Implemented:
- Worker registry.
- Lab task queue.
- Capability matching.
- Policy denial for prohibited capabilities.
- Task claims.
- Task results.
- Datacampus assignment import.
- CLI and tests.
- CLI smoke claim/result flow.
- Local-only HTTP API with optional token guard.
- Lough export for task lifecycle records.

## Phase 1 - Swarm Bridge

Tasks:
- Add zeroclaw and openclaw worker profiles.
- Add worker heartbeat records.
- Add task lease expiration.
- Add review-required routing to datacampus.
- Add Lough export deduplication or export watermarking.

## Phase 2 - Service API

Tasks:
- Add API tests for datacampus import.
- Add task lease expiration.
- Add worker heartbeat.

## Boundary

The broker assigns lab work only. It does not execute arbitrary commands or orchestrate real-world operations.
