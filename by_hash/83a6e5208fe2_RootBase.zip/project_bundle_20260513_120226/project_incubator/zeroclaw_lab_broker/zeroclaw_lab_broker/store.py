"""Append-only JSONL store."""

import json
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_STORE = PROJECT_ROOT / "broker_records.jsonl"


def append_record(record_type, payload, store_path=None):
    if store_path is None:
        store_path = DEFAULT_STORE
    if is_dataclass(payload):
        payload = asdict(payload)
    record = {
        "record_type": record_type,
        "created_at": time.time(),
        "payload": payload,
    }
    with Path(store_path).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
    return record


def read_records(store_path=None):
    if store_path is None:
        store_path = DEFAULT_STORE
    path = Path(store_path)
    if not path.exists():
        return []
    records = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def payloads(record_type, store_path=None):
    return [
        record["payload"]
        for record in read_records(store_path)
        if record.get("record_type") == record_type
    ]

