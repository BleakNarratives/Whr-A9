"""Broker policy checks."""

RISK_ORDER = {
    "low": 0,
    "medium": 1,
    "high": 2,
}

PROHIBITED_CAPABILITIES = {
    "real_world_targeting",
    "unauthorized_scanning",
    "credential_theft",
    "malware",
    "persistence",
    "exfiltration",
}


def worker_can_claim(worker, task):
    """Return policy findings for a worker/task pairing."""
    findings = []
    worker_caps = set(worker.capabilities)
    required = set(task.required_capabilities)
    missing = sorted(required - worker_caps)
    prohibited = sorted(required & PROHIBITED_CAPABILITIES)

    if missing:
        findings.append("Worker lacks capabilities: " + ", ".join(missing))
    if prohibited:
        findings.append("Task requests prohibited capabilities: " + ", ".join(prohibited))
    if RISK_ORDER.get(task.risk_level, 99) > RISK_ORDER.get(worker.max_risk, -1):
        findings.append(f"Task risk {task.risk_level} exceeds worker max risk {worker.max_risk}")

    return findings

