"""Local HTTP API for Zeroclaw Lab Broker."""

import os

from flask import Flask, jsonify, request

from . import broker
from .store import read_records

app = Flask(__name__)

API_TOKEN = os.getenv("ZLB_API_TOKEN")
ALLOW_REMOTE = os.getenv("ZLB_ALLOW_REMOTE", "0") == "1"
LOCAL_ADDRS = {"127.0.0.1", "::1", "localhost"}


@app.before_request
def enforce_access_policy():
    if _authorized_request():
        return None
    return jsonify({
        "error": "Unauthorized",
        "detail": "Set ZLB_API_TOKEN and send X-ZLB-Token, or keep requests local.",
    }), 401


@app.route("/status", methods=["GET"])
def status():
    return jsonify(broker.broker_status())


@app.route("/workers", methods=["GET"])
def workers():
    return jsonify(broker.list_workers())


@app.route("/workers", methods=["POST"])
def register_worker():
    data = request.get_json(force=True)
    worker = broker.register_worker(
        name=data["name"],
        capabilities=data.get("capabilities", []),
        max_risk=data.get("max_risk", "low"),
        metadata=data.get("metadata", {}),
    )
    return jsonify(worker.__dict__), 201


@app.route("/tasks", methods=["GET"])
def tasks():
    return jsonify(broker.list_open_tasks())


@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.get_json(force=True)
    task = broker.create_task(
        assignment_id=data["assignment_id"],
        lab_id=data["lab_id"],
        required_capabilities=data.get("required_capabilities", []),
        source=data.get("source", "api"),
        review_required=data.get("review_required", True),
        risk_level=data.get("risk_level", "low"),
        payload=data.get("payload", {}),
    )
    return jsonify(task.__dict__), 201


@app.route("/claims", methods=["POST"])
def claim():
    data = request.get_json(force=True)
    claim_result = broker.claim_task(
        task_id=data["task_id"],
        worker_id=data["worker_id"],
    )
    if hasattr(claim_result, "__dict__"):
        return jsonify(claim_result.__dict__), 201
    return jsonify(claim_result), 409


@app.route("/results", methods=["POST"])
def result():
    data = request.get_json(force=True)
    task_result = broker.submit_result(
        task_id=data["task_id"],
        worker_id=data["worker_id"],
        status=data["status"],
        evidence=data.get("evidence", {}),
    )
    return jsonify(task_result.__dict__), 201


@app.route("/records", methods=["GET"])
def records():
    return jsonify(read_records())


def _authorized_request():
    if API_TOKEN:
        supplied = request.headers.get("X-ZLB-Token") or request.args.get("token")
        return supplied == API_TOKEN
    if ALLOW_REMOTE:
        return True
    return request.remote_addr in LOCAL_ADDRS


if __name__ == "__main__":
    print("[ZLB] Running on http://127.0.0.1:7081")
    app.run(host="127.0.0.1", port=7081)
