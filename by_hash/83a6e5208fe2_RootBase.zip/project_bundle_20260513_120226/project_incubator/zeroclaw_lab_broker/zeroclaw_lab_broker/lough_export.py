"""Export broker lifecycle records into Lough System."""

import sys

LOUGH_PATH = "/data/data/com.termux/files/home/lough_system"

EVENT_TYPES = {
    "task.created": "zeroclaw_broker.task.created",
    "task.claimed": "zeroclaw_broker.task.claimed",
    "task.result": "zeroclaw_broker.task.result",
    "task.claim_denied": "zeroclaw_broker.task.claim_denied",
}


def export_record(record):
    """Export one broker record to Lough if it is a supported lifecycle event."""
    record_type = record.get("record_type")
    event_type = EVENT_TYPES.get(record_type)
    if event_type is None:
        return {
            "exported": False,
            "reason": "unsupported_record_type",
            "record_type": record_type,
        }

    field_bridge = _load_field_bridge()
    payload = {
        "broker_record_type": record_type,
        "broker_created_at": record.get("created_at"),
        **record.get("payload", {}),
    }
    field_bridge.emit(
        event_type=event_type,
        location="zeroclaw.lab_broker",
        source="zeroclaw_lab_broker",
        payload=payload,
        provenance={"exporter": "zeroclaw_lab_broker.lough_export"},
        created_by="zeroclaw_lab_broker",
    )
    return {
        "exported": True,
        "event_type": event_type,
    }


def export_records(records):
    """Export supported records and return export results."""
    return [export_record(record) for record in records]


def _load_field_bridge():
    if LOUGH_PATH not in sys.path:
        sys.path.insert(0, LOUGH_PATH)
    import field_bridge
    return field_bridge
