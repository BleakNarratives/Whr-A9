"""ID helpers."""

import hashlib


def make_id(prefix, *parts):
    raw = ":".join(str(part) for part in parts)
    digest = hashlib.sha256(raw.encode()).hexdigest()[:12]
    return f"{prefix}_{digest}"

