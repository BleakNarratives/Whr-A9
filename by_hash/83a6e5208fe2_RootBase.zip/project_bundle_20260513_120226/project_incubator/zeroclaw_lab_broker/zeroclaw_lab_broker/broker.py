"""Core broker operations."""

import os

from . import lough_export
from .ids import make_id
from .models import LabTask, TaskClaim, TaskResult, Worker
from .policy import worker_can_claim
from .store import append_record, payloads, read_records


def register_worker(name, capabilities, max_risk="low", metadata=None):
    worker = Worker(
        worker_id=make_id("worker", name, ",".join(sorted(capabilities))),
        name=name,
        capabilities=capabilities,
        max_risk=max_risk,
        metadata=metadata or {},
    )
    _record("worker.registered", worker)
    return worker


def create_task(
    assignment_id,
    lab_id,
    required_capabilities,
    source="datacampus",
    review_required=True,
    risk_level="low",
    payload=None,
):
    task = LabTask(
        task_id=make_id("task", assignment_id, lab_id, len(read_records())),
        source=source,
        assignment_id=assignment_id,
        lab_id=lab_id,
        required_capabilities=required_capabilities,
        review_required=review_required,
        risk_level=risk_level,
        payload=payload or {},
    )
    _record("task.created", task)
    return task


def list_open_tasks():
    claimed = {
        claim["task_id"]
        for claim in payloads("task.claimed")
        if claim.get("status") in {"claimed", "running"}
    }
    completed = {
        result["task_id"]
        for result in payloads("task.result")
        if result.get("status") in {"completed", "blocked", "failed"}
    }
    return [
        task
        for task in payloads("task.created")
        if task["task_id"] not in claimed and task["task_id"] not in completed
    ]


def list_workers():
    return payloads("worker.registered")


def get_worker(worker_id):
    return _find_payload("worker.registered", "worker_id", worker_id)


def get_task(task_id):
    return _find_payload("task.created", "task_id", task_id)


def claim_task(task_id, worker_id):
    worker = _find_payload("worker.registered", "worker_id", worker_id)
    task = _find_payload("task.created", "task_id", task_id)
    if worker is None:
        raise ValueError(f"Unknown worker: {worker_id}")
    if task is None:
        raise ValueError(f"Unknown task: {task_id}")

    worker_model = Worker(**worker)
    task_model = LabTask(**task)
    findings = worker_can_claim(worker_model, task_model)
    if findings:
        _record("task.claim_denied", {
            "task_id": task_id,
            "worker_id": worker_id,
            "findings": findings,
        })
        return {
            "status": "denied",
            "findings": findings,
        }

    claim = TaskClaim(
        claim_id=make_id("claim", task_id, worker_id),
        task_id=task_id,
        worker_id=worker_id,
        status="claimed",
    )
    _record("task.claimed", claim)
    return claim


def submit_result(task_id, worker_id, status, evidence):
    task = _find_payload("task.created", "task_id", task_id)
    if task is None:
        raise ValueError(f"Unknown task: {task_id}")
    result = TaskResult(
        result_id=make_id("result", task_id, worker_id, status, len(read_records())),
        task_id=task_id,
        worker_id=worker_id,
        status=status,
        evidence=evidence,
        review_required=bool(task.get("review_required", True)),
    )
    _record("task.result", result)
    return result


def broker_status():
    return {
        "workers": len(payloads("worker.registered")),
        "tasks_created": len(payloads("task.created")),
        "open_tasks": len(list_open_tasks()),
        "claims": len(payloads("task.claimed")),
        "results": len(payloads("task.result")),
        "denials": len(payloads("task.claim_denied")),
    }


def smoke_claim_result():
    """Claim the newest open task with the newest compatible worker and submit a smoke result."""
    workers = list_workers()
    tasks = list_open_tasks()
    if not workers:
        raise ValueError("No workers registered.")
    if not tasks:
        raise ValueError("No open tasks available.")

    worker = workers[-1]
    task = tasks[-1]
    claim = claim_task(task["task_id"], worker["worker_id"])
    if isinstance(claim, dict) and claim.get("status") == "denied":
        return {
            "claim": claim,
            "result": None,
        }
    result = submit_result(
        task_id=task["task_id"],
        worker_id=worker["worker_id"],
        status="completed",
        evidence={"summary": "smoke flow completed", "mode": "manual_cli"},
    )
    return {
        "claim": claim,
        "result": result,
    }


def import_datacampus_assignments(records):
    """Create broker tasks from datacampus assignment records."""
    tasks = []
    for record in records:
        if record.get("record_type") != "assignment.created":
            continue
        assignment = record["payload"]
        tasks.append(create_task(
            assignment_id=assignment["assignment_id"],
            lab_id=assignment["lab_id"],
            required_capabilities=["fixture_read", "mock_simulation", "evidence_submit"],
            source="datacampus",
            review_required=assignment.get("review_required", True),
            risk_level="low",
            payload={"source_project": assignment.get("source_project")},
        ))
    return tasks


def _find_payload(record_type, key, value):
    for payload in reversed(payloads(record_type)):
        if payload.get(key) == value:
            return payload
    return None


def _record(record_type, payload):
    record = append_record(record_type, payload)
    if os.getenv("ZLB_LOUGH_EXPORT", "0") == "1":
        lough_export.export_record(record)
    return record
