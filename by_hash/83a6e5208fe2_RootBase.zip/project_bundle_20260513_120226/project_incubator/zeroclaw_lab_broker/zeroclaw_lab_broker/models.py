"""Data models for lab task brokerage."""

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Worker:
    worker_id: str
    name: str
    capabilities: list[str]
    max_risk: str = "low"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LabTask:
    task_id: str
    source: str
    assignment_id: str
    lab_id: str
    required_capabilities: list[str]
    review_required: bool
    risk_level: str
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TaskClaim:
    claim_id: str
    task_id: str
    worker_id: str
    status: str


@dataclass(frozen=True)
class TaskResult:
    result_id: str
    task_id: str
    worker_id: str
    status: str
    evidence: dict[str, Any]
    review_required: bool

