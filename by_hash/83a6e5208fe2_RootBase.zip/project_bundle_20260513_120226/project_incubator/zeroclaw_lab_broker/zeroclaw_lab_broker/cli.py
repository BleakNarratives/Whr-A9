"""Zeroclaw Lab Broker CLI."""

import argparse
import json
from dataclasses import asdict, is_dataclass
from pathlib import Path

from .broker import (
    broker_status,
    claim_task,
    create_task,
    import_datacampus_assignments,
    list_open_tasks,
    register_worker,
    smoke_claim_result,
    submit_result,
)
from .lough_export import export_records
from .store import read_records


def _print(value):
    value = _to_jsonable(value)
    print(json.dumps(value, indent=2, sort_keys=True))


def _to_jsonable(value):
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, list):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: _to_jsonable(item) for key, item in value.items()}
    return value


def main():
    parser = argparse.ArgumentParser(description="Zeroclaw Lab Broker")
    subparsers = parser.add_subparsers(dest="command", required=True)

    worker_parser = subparsers.add_parser("register-worker")
    worker_parser.add_argument("--name", required=True)
    worker_parser.add_argument("--capability", action="append", required=True)
    worker_parser.add_argument("--max-risk", default="low")

    task_parser = subparsers.add_parser("create-task")
    task_parser.add_argument("--assignment-id", required=True)
    task_parser.add_argument("--lab-id", required=True)
    task_parser.add_argument("--capability", action="append", required=True)
    task_parser.add_argument("--risk-level", default="low")

    claim_parser = subparsers.add_parser("claim")
    claim_parser.add_argument("--task-id", required=True)
    claim_parser.add_argument("--worker-id", required=True)

    result_parser = subparsers.add_parser("submit-result")
    result_parser.add_argument("--task-id", required=True)
    result_parser.add_argument("--worker-id", required=True)
    result_parser.add_argument("--status", required=True)
    result_parser.add_argument("--evidence-json", default="{}")

    import_parser = subparsers.add_parser("import-datacampus")
    import_parser.add_argument("path")

    subparsers.add_parser("export-lough")
    subparsers.add_parser("open-tasks")
    subparsers.add_parser("status")
    subparsers.add_parser("records")
    subparsers.add_parser("smoke-claim-result")

    args = parser.parse_args()

    if args.command == "register-worker":
        _print(register_worker(args.name, args.capability, max_risk=args.max_risk))
    elif args.command == "create-task":
        _print(create_task(
            assignment_id=args.assignment_id,
            lab_id=args.lab_id,
            required_capabilities=args.capability,
            risk_level=args.risk_level,
        ))
    elif args.command == "claim":
        _print(claim_task(args.task_id, args.worker_id))
    elif args.command == "submit-result":
        _print(submit_result(
            args.task_id,
            args.worker_id,
            args.status,
            json.loads(args.evidence_json),
        ))
    elif args.command == "import-datacampus":
        records = [
            json.loads(line)
            for line in Path(args.path).read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        _print(import_datacampus_assignments(records))
    elif args.command == "export-lough":
        _print(export_records(read_records()))
    elif args.command == "open-tasks":
        _print(list_open_tasks())
    elif args.command == "status":
        _print(broker_status())
    elif args.command == "records":
        _print(read_records())
    elif args.command == "smoke-claim-result":
        _print(smoke_claim_result())


if __name__ == "__main__":
    main()
