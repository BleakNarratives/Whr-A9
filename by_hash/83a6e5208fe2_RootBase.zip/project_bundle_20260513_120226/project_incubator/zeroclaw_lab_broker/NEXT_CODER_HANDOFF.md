# Zeroclaw Lab Broker Handoff

Status: Local broker + API + Lough export implemented.

## What Exists

- Worker registry.
- Task queue.
- Capability matching.
- Claim denial for prohibited capabilities.
- Claim/result flow.
- Local HTTP API with token guard.
- Datacampus assignment import.
- Lough lifecycle export.
- CLI and tests.

## Commands

```bash
python -m py_compile zeroclaw_lab_broker/*.py tests/*.py
python -m unittest discover -s tests -v
python -m zeroclaw_lab_broker.cli status
python -m zeroclaw_lab_broker.cli export-lough
```

API:

```bash
export ZLB_API_TOKEN="replace-with-long-random-token"
python -m zeroclaw_lab_broker.server
```

## Latest Verification

- Compile passed.
- Unit suite passed with 9 tests.
- `export-lough` emitted task lifecycle records into Lough.

## Next Work

1. Add worker heartbeat.
2. Add task claim lease expiration.
3. Add Lough export watermarking to prevent duplicate exports.
4. Add API endpoint for datacampus JSONL import.

## Safety

Do not add arbitrary command execution. Workers are capability records and evidence submitters, not unrestricted shells.
