# Simulation Foundry

Purpose:
Generate safe mock environments for training, testing, and scenario evaluation.

Useful output:
- mock agents,
- mock tools,
- mock transcripts,
- synthetic event streams,
- sandbox lifecycle fixtures.

Potential revenue path:
- custom simulation packs,
- training environments,
- reproducible evaluation suites.

First build:
- Fixture generator.
- Mock tool-call recorder.
- Datacampus sandbox vault integration.
- Artificial-Criminal scenario import.

Boundary:
- Simulated targets only.
- No deployable exploit environments.
- No credential or malware realism.

