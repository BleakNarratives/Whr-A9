# Agentic Curriculum Exchange

Purpose:
Package, version, and trade safe lab curricula between local projects and trusted collaborators.

Useful output:
- signed curriculum bundles,
- manifest validation,
- import/export records,
- review and provenance metadata.

Potential revenue path:
- paid curriculum bundles,
- instructor packs,
- cohort training tracks,
- consulting-backed lab design.

First build:
- Bundle manifest schema.
- Import validator.
- Export from datacampus and Artificial-Criminal.
- Provenance and review status checks.

Boundary:
- No unreviewed adversarial content.
- No harmful operational details.
- No opaque curriculum imports.

