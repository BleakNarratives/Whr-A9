# Project Incubator

This directory holds next-step project stubs that can become separate workflows.

Selection principles:
- novel enough to matter,
- useful to the Lough, Artificial-Criminal, datacampus, zeroclaw, and openclaw ecosystem,
- capable of producing legitimate value,
- local-first and low-cost by default,
- safe, auditable, and reviewable.

Current stubs:
- `openclaw_market_signals`
- `zeroclaw_lab_broker`
- `pattern_atlas`
- `ethics_vault`
- `simulation_foundry`
- `agentic_curriculum_exchange`

