import subprocess
import json
import re
import sys
import os

class ModindExecutor:
    def __init__(self):
        # Path to your Modind unified directory
        self.modind_base = os.path.expanduser("~/modind_unified")

    def parse_recommendations(self, vertical_output):
        """Extracts actionable tasks from the board report using regex patterns."""
        tasks = []
        # Looks for patterns like 'Recommend [task]', 'Should [task]', or 'I need [task]'
        patterns = [
            r"recommend\s+(.+?)\.", 
            r"should\s+(.+?)\.", 
            r"I\s+need\s+(.+?)\."
        ]
        for pattern in patterns:
            matches = re.findall(pattern, vertical_output, re.IGNORECASE)
            tasks.extend(matches)
        return list(set(tasks)) # Remove duplicates

    def spawn_agent(self, task_description, priority="medium"):
        """Maps task keywords to agent types and triggers the Modind manager."""
        task_lower = task_description.lower()
        
        # Keyword-to-Agent Mapping Logic
        if any(kw in task_lower for kw in ["research", "analyze", "investigate"]):
            agent_type = "researcher"
        elif any(kw in task_lower for kw in ["build", "develop", "create"]):
            agent_type = "builder"
        elif any(kw in task_lower for kw in ["test", "validate", "verify"]):
            agent_type = "validator"
        else:
            agent_type = "general"

        # Construct the core shell command to spawn the worker
        cmd = f"bash {self.modind_base}/agent_manager.sh spawn {agent_type} '{task_description}' {priority}"
        
        print(f"Executing: {cmd}")
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
            return {"success": result.returncode == 0, "agent": agent_type, "task": task_description, "output": result.stdout}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def execute_report(self, report_path):
        """Processes the entire report and spawns all necessary agents."""
        if not os.path.exists(report_path):
            print(f"Error: Report not found at {report_path}")
            return []

        with open(report_path, 'r') as f:
            report_text = f.read()

        tasks = self.parse_recommendations(report_text)
        results = []
        for task in tasks:
            print(f"🚀 Spawning agent for task: {task}")
            results.append(self.spawn_agent(task))
        return results

if __name__ == "__main__":
    executor = ModindExecutor()
    if len(sys.argv) > 1:
        report_file = sys.argv[1]
        if report_file == "--test-mode":
            print("Running in test mode...")
            dummy_report = "I recommend analyzing the biometric feedback. We should build a new UI component. I need to verify the database integrity."
            tasks = executor.parse_recommendations(dummy_report)
            print(f"Parsed tasks: {tasks}")
            for t in tasks:
                executor.spawn_agent(t)
        else:
            executor.execute_report(report_file)
    else:
        print("Usage: python vertical_modind_executor.py [report_file | --test-mode]")
