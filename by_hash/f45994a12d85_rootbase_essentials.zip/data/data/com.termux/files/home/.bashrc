alias arena='python3 /storage/emulated/0/RootBase/Whorl/arena/run.py'
alias standings='python3 /storage/emulated/0/RootBase/Whorl/arena/run.py report'
alias swarmlogs='python3 /storage/emulated/0/RootBase/logs/swarm_log.py tail 30'
alias snap='/storage/emulated/0/RootBase/.nat/nat_snap.sh'
alias open-haley='termux-open /sdcard/Download/AskHer/HAILEY_v_3.html'
alias v-status='python3 /data/data/com.termux/files/home/RootBase/swarm_bridge.py'

# ---- Valet key loader (absolute paths) ----
load_vault_key() {
    local key_name=$1
    local key_file="/storage/emulated/0/RootBase/vault/keys/${key_name}.key"
    if [[ -f "$key_file" ]]; then
        export "${key_name^^}_API_KEY"="$(cat "$key_file" | tr -d '\n\r')"
        echo "✅ Loaded $key_name"
    else
        echo "❌ Key $key_name not found"
    fi
}
load_vault_key openrouter
load_vault_key gemini
alias concierge='python3 /storage/emulated/0/RootBase/concierge/engine.py'
