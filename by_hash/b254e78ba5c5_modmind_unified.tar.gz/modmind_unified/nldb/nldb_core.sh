#!/bin/bash
# NLDB Core Management
# Usage: ./nldb_core.sh [add|query|list|snapshot] [content]

COMMAND=$1
CONTENT=$2
DATA_DIR="$HOME/modmind_unified/nldb/data"
LOG_DIR="$HOME/modmind_unified/nldb/logs"

# Initialize directories
mkdir -p "$DATA_DIR" "$LOG_DIR"

case $COMMAND in
    add)
        TIMESTAMP=$(date +%s)
        echo "$TIMESTAMP|$CONTENT" >> "$DATA_DIR/entries.log"
        echo "[ENTRY ADDED: $TIMESTAMP]"
        ;;
    query)
        grep "$CONTENT" "$DATA_DIR/entries.log" || echo "No matches found"
        ;;
    list)
        cat "$DATA_DIR/entries.log"
        ;;
    snapshot)
        SNAPSHOT_FILE="$LOG_DIR/snapshot_$TIMESTAMP.log"
        {
            echo "--- SNAPSHOT $(date) ---"
            echo "PWD: $PWD"
            echo "--- ENVIRONMENT ---"
            export | grep -v 'BASH_FUNC'
            echo "--- PROCESSES ---"
            ps -o pid,args | grep -v 'grep' | grep -v 'ps'
        } > "$SNAPSHOT_FILE"
        echo "[SNAPSHOT SAVED: $SNAPSHOT_FILE]"
        ;;
    *)
        echo "Usage: $0 [add|query|list|snapshot] [content]"
        ;;
esac
