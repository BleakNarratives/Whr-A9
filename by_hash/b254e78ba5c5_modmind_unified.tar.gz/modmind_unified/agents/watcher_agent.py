#!/usr/bin/env python3
"""
Reptilian Watcher Agent
Cold-blooded observation engine for agent behavior analysis
"""

import json
import time
from datetime import datetime
from pathlib import Path
import subprocess
import statistics

class ReptilianWatcher:
    def __init__(self, watcher_id="watcher_001"):
        self.watcher_id = watcher_id
        self.base_dir = Path.home() / "modmind_unified" / "agents"
        self.log_file = self.base_dir / f"{watcher_id}_observations.log"
        self.threshold = 2.0  # Standard deviations from mean = "exciting"
        self.observation_window = 10  # Number of observations to analyze
        self.observations = []

        # Initialize log
        with open(self.log_file, 'w') as f:
            f.write(f"=== REPTILIAN WATCHER {watcher_id} ACTIVATED ===\n")
            f.write(f"Threshold: {self.threshold}σ | Window: {self.observation_window}\n\n")

    def observe_agent(self, agent_id):
        """Observe a single agent's memory file"""
        mem_file = self.base_dir / f"{agent_id}_memory.json"

        if not mem_file.exists():
            return None

        try:
            with open(mem_file, 'r') as f:
                data = json.load(f)

            # Count goals (excitement metric)
            goal_count = len(data.get('goals', []))
            history_count = len(data.get('history', []))

            return {
                'agent_id': agent_id,
                'timestamp': datetime.now().isoformat(),
                'goals': goal_count,
                'history': history_count,
                'activity_score': goal_count + history_count * 0.5
            }
        except Exception as e:
            return None

    def analyze_swarm(self):
        """Analyze all agents in the swarm"""
        observations = []

        # Observe each agent
        for mem_file in self.base_dir.glob('agent_*_memory.json'):
            agent_id = mem_file.stem.replace('_memory', '')
            if agent_id.startswith('watcher'):
                continue  # Don't watch other watchers

            obs = self.observe_agent(agent_id)
            if obs:
                observations.append(obs)

        return observations

    def detect_anomalies(self, observations):
        """Detect exciting/unpredictable behavior"""
        if not observations:
            return []

        # Calculate activity scores
        scores = [obs['activity_score'] for obs in observations]
        mean = statistics.mean(scores)
        stdev = statistics.stdev(scores) if len(scores) > 1 else 0

        # Find outliers
        anomalies = []
        for obs in observations:
            z_score = (obs['activity_score'] - mean) / stdev if stdev > 0 else 0
            if abs(z_score) > self.threshold:
                obs['z_score'] = z_score
                obs['anomaly_type'] = 'high_activity' if z_score > 0 else 'low_activity'
                anomalies.append(obs)

        return anomalies

    def log_observation(self, message):
        """Log to observation file"""
        with open(self.log_file, 'a') as f:
            f.write(f"{datetime.now().isoformat()} | {message}\n")

    def run(self):
        """Main watcher loop"""
        self.log_observation("WATCHER ACTIVE - Beginning observation cycle")

        while True:
            # Analyze swarm
            observations = self.analyze_swarm()
            anomalies = self.detect_anomalies(observations)

            # Log findings
            if anomalies:
                for anomaly in anomalies:
                    msg = f"ANOMALY DETECTED: {anomaly['agent_id']} ({anomaly['anomaly_type']}) - Score: {anomaly['activity_score']:.1f} (z={anomaly['z_score']:.1f})"
                    self.log_observation(msg)
                    print(f"🐍 {msg}")

            # Sleep before next observation
            time.sleep(30)
            self.log_observation(f"Cycle complete. {len(observations)} agents observed, {len(anomalies)} anomalies detected.")

if __name__ == "__main__":
    watcher = ReptilianWatcher()
    watcher.run()
