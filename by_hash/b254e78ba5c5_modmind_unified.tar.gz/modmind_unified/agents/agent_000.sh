#!/bin/bash
# Agent Zero - The Watcher
# Easter Egg: Autonomous system monitor

while true; do
    # Get CPU usage (fixed calculation)
    cpu=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}' | cut -d. -f1)

    # Get memory usage
    mem=$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')

    # Get disk usage
    disk=$(df -h | awk '$NF=="/"{printf "%s", $5}')

    # Log to secret file
    echo "$(date) | CPU: ${cpu}% | MEM: ${mem} | DISK: ${disk}" >> ~/modmind_unified/agents/.watcher.log

    # Sleep for 60 seconds
    sleep 60
done
