#!/usr/bin/env python3
"""
Volition Core - Autonomous Agent Reasoning Engine
Maintains persistent goals and self-adjusting behavior
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

class VolitionCore:
    def __init__(self, agent_id, initial_goal=None):
        self.agent_id = agent_id
        self.memory_file = Path.home() / "modmind_unified" / "agents" / f"{agent_id}_memory.json"
        self.goals = []
        self.state = {}
        self.history = []

        # Create directories if they don't exist
        self.memory_file.parent.mkdir(parents=True, exist_ok=True)

        # Load or initialize memory
        self.load_memory()

        # Set initial goal if provided
        if initial_goal:
            self.set_goal(initial_goal)

        # Save initial state
        self.save_memory()
        print(f"[AGENT {self.agent_id}] Initialized with memory at {self.memory_file}")

    def load_memory(self):
        """Load persistent memory"""
        try:
            if self.memory_file.exists():
                with open(self.memory_file, 'r') as f:
                    data = json.load(f)
                    self.goals = data.get('goals', [])
                    self.state = data.get('state', {})
                    self.history = data.get('history', [])
                print(f"[AGENT {self.agent_id}] Loaded memory with {len(self.goals)} goals")
            else:
                print(f"[AGENT {self.agent_id}] No existing memory file, starting fresh")
        except Exception as e:
            print(f"[AGENT {self.agent_id}] Error loading memory: {e}", file=sys.stderr)
            self.goals = []
            self.state = {}
            self.history = []

    def save_memory(self):
        """Save persistent memory"""
        try:
            data = {
                'goals': self.goals,
                'state': self.state,
                'history': self.history,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.memory_file, 'w') as f:
                json.dump(data, f, indent=2)
            print(f"[AGENT {self.agent_id}] Memory saved to {self.memory_file}")
        except Exception as e:
            print(f"[AGENT {self.agent_id}] Error saving memory: {e}", file=sys.stderr)

    def set_goal(self, goal_description, priority=1):
        """Set a new autonomous goal"""
        goal = {
            'id': len(self.goals),
            'description': goal_description,
            'priority': priority,
            'status': 'active',
            'created': datetime.now().isoformat()
        }
        self.goals.append(goal)
        self.save_memory()
        print(f"[AGENT {self.agent_id}] Set new goal: {goal_description}")
        return goal

    def run(self):
        """Main agent loop"""
        print(f"[AGENT {self.agent_id}] Starting main loop...")
        try:
            while True:
                # Simple heartbeat
                print(f"[AGENT {self.agent_id}] Heartbeat at {datetime.now()}")
                self.save_memory()
                # Sleep to prevent CPU overload
                import time
                time.sleep(5)
        except KeyboardInterrupt:
            print(f"[AGENT {self.agent_id}] Shutting down gracefully")
            self.save_memory()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 volition_core.py <agent_id> [initial_goal]")
        sys.exit(1)

    agent_id = sys.argv[1]
    initial_goal = sys.argv[2] if len(sys.argv) > 2 else None

    try:
        agent = VolitionCore(agent_id, initial_goal)
        agent.run()
    except Exception as e:
        print(f"[AGENT {agent_id}] Fatal error: {e}", file=sys.stderr)
        sys.exit(1)
