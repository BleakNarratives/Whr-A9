#!/bin/bash
# Spawn Reptilian Watcher Agents

AGENT_DIR="$HOME/modmind_unified/agents"

# Spawn primary watcher
nohup python3 "$AGENT_DIR/watcher_agent.py" > "$AGENT_DIR/watcher_001.log" 2>&1 &
echo "Reptilian Watcher deployed (PID: $!)"

# Optional: Spawn secondary watcher for redundancy
# nohup python3 "$AGENT_DIR/watcher_agent.py" watcher_002 > "$AGENT_DIR/watcher_002.log" 2>&1 &
# echo "Secondary Watcher deployed (PID: $!)"

echo "Reptilian Observation Matrix online"
