#!/bin/bash
# Swarm Spawner - Launch multiple agents simultaneously

AGENT_DIR="$HOME/modmind_unified/agents"

# Agent definitions
declare -a AGENTS=(
    "agent_001:Maintain system stability"
    "agent_002:Monitor resource usage"
    "agent_003:Analyze log patterns"
    "agent_004:Optimize performance"
)

# Spawn all agents
for agent_def in "${AGENTS[@]}"; do
    IFS=':' read -r agent_id goal <<< "$agent_def"
    echo "Spawning $agent_id with goal: $goal"
    nohup python3 "$AGENT_DIR/volition_core.py" "$agent_id" "$goal" > "$AGENT_DIR/${agent_id}.log" 2>&1 &
    echo $! > "$AGENT_DIR/${agent_id}.pid"
    sleep 1  # Stagger startup
done

echo "Swarm activated: ${#AGENTS[@]} agents deployed"
