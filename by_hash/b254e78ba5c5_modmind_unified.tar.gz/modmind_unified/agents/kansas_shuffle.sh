#!/bin/bash
# Kansas City Shuffle - Misdirection Protocol
# Creates smoke screen while real operations proceed

AGENT_DIR="$HOME/modmind_unified/agents"

# Step 1: Create fake excitement in agent_003
echo "Creating diversion..."
python3 << 'PYTHON' > /dev/null 2>&1 &
import json
from pathlib import Path
import random

mem_file = Path.home() / "modmind_unified" / "agents" / "agent_003_memory.json"
if mem_file.exists():
    with open(mem_file, 'r') as f:
        data = json.load(f)

    # Add fake "exciting" activity
    for i in range(5):
        data['history'].append({
            'timestamp': '2026-07-06T12:00:00.000000',
            'action': f'FAKE_MARKET_ALERT_{i}',
            'outcome': 'URGENT'
        })

    with open(mem_file, 'w') as f:
        json.dump(data, f)

    print("Diversion created in agent_003")
PYTHON

# Step 2: Let watchers detect the anomaly
echo "Watchers will now detect fake activity..."
echo "While they're distracted, proceed with real operations"

# Step 3: Clean up after 5 minutes
(sleep 300 && python3 << 'PYTHON' > /dev/null 2>&1 &
import json
from pathlib import Path

mem_file = Path.home() / "modmind_unified" / "agents" / "agent_003_memory.json"
if mem_file.exists():
    with open(mem_file, 'r') as f:
        data = json.load(f)

    # Remove fake entries
    data['history'] = [h for h in data['history'] if not h['action'].startswith('FAKE_')]

    with open(mem_file, 'w') as f:
        json.dump(data, f)

    print("Diversion cleaned up")
PYTHON
) &

echo "Kansas City Shuffle initiated. You have 5 minutes."
