#!/bin/bash
# Swarm Monitor - Check status of all agents

AGENT_DIR="$HOME/modmind_unified/agents"

echo "=== AGENT SWARM STATUS ==="
echo "Timestamp: $(date)"
echo ""

running_count=0
total_count=0

for pid_file in "$AGENT_DIR"/*.pid; do
    [ -f "$pid_file" ] || continue
    total_count=$((total_count + 1))

    agent_id=$(basename "$pid_file" .pid)
    pid=$(cat "$pid_file" 2>/dev/null)

    # More robust process checking
    if [ -n "$pid" ] && ps -p "$pid" > /dev/null 2>&1; then
        status="🟢 RUNNING"
        running_count=$((running_count + 1))

        # Get uptime
        uptime=$(ps -p "$pid" -o etime= 2>/dev/null || echo "unknown")

        # Count goals safely
        mem_file="$AGENT_DIR/${agent_id}_memory.json"
        if [ -f "$mem_file" ]; then
            goals=$(jq '.goals | length' "$mem_file" 2>/dev/null || echo "0")
        else
            goals="0"
        fi
    else
        status="🔴 DEAD"
        uptime="N/A"
        goals="N/A"
        # Clean up dead agent files
        rm -f "$pid_file" "$AGENT_DIR/${agent_id}.pid" 2>/dev/null
    fi

    echo "$agent_id ($pid): $status | Uptime: $uptime | Goals: $goals"
done

echo ""
echo "=== SWARM METRICS ==="
echo "Total Agents: $total_count"
echo "Running Agents: $running_count"

if [ $total_count -gt 0 ]; then
    success_rate=$((running_count * 100 / total_count))
else
    success_rate=0
fi

echo "Success Rate: ${success_rate}%"

# Show memory file sample
if [ $running_count -gt 0 ]; then
    echo ""
    echo "=== SAMPLE MEMORY (agent_001) ==="
    cat "$AGENT_DIR/agent_001_memory.json" 2>/dev/null | head -20
fi
