#!/bin/bash
# Agent Manager - Spawn and manage autonomous agents

AGENT_DIR="$HOME/modmind_unified/agents"
PYTHON="python3"

# Create agent directory
mkdir -p "$AGENT_DIR"

# Function to spawn an agent
spawn_agent() {
    local agent_id=$1
    local goal=$2

    echo "Spawning agent $agent_id with goal: $goal"
    nohup $PYTHON "$AGENT_DIR/volition_core.py" "$agent_id" "$goal" > "$AGENT_DIR/${agent_id}.log" 2>&1 &
    local pid=$!
    echo "Agent $agent_id spawned with PID $pid"
    echo $pid > "$AGENT_DIR/${agent_id}.pid"
}

# Function to check agent status
check_agent() {
    local agent_id=$1
    local pid_file="$AGENT_DIR/${agent_id}.pid"

    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        if ps -p $pid > /dev/null; then
            echo "Agent $agent_id is running (PID $pid)"
            return 0
        else
            echo "Agent $agent_id is not running (PID $pid not found)"
            return 1
        fi
    else
        echo "No PID file found for agent $agent_id"
        return 1
    fi
}

# Example usage
case "$1" in
    spawn)
        spawn_agent "$2" "$3"
        ;;
    check)
        check_agent "$2"
        ;;
    *)
        echo "Usage: $0 [spawn|check] [agent_id] [goal]"
        ;;
esac
