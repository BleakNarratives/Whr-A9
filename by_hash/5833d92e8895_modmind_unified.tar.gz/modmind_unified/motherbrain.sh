#!/bin/bash
# MotherBrain Deployment - Total Swarm Activation

echo "🔥 IGNITING MOTHERBRAIN..."

# 1. Start the Hebbian Memory Ledger
# 2. Deploy the Reptilian Watcher Matrix
# 3. Spin up the Transcendent Swarm

cd ~/modmind_unified/agents

# Clear old logs to ensure clean data for the trial
rm -f /storage/emulated/0/RootBase/transcendence_*.log

# Deploy Watchers
./spawn_watchers.sh

# Deploy Swarm with Persistence
./run_transcendent_swarm.sh

echo "MotherBrain is ONLINE. Vertical movement initialized."
