#!/usr/bin/env python3
"""
Volition Core - Autonomous Agent Reasoning Engine
Maintains persistent goals, gathers real system telemetry, and thinks dynamically with timeouts.
"""

import json
import os
import sys
import shutil
from datetime import datetime
from pathlib import Path
import time
import concurrent.futures

try:
    from unknown_need_engine import UnknownNeedEngine
except ImportError:
    class UnknownNeedEngine:
        def suggest(self, goal): return "💡 [Need Engine] Ready to analyze."

class VolitionCore:
    def __init__(self, agent_id, initial_goal=None):
        self.agent_id = agent_id
        self.memory_file = Path.home() / "modmind_unified" / "agents" / f"{agent_id}_memory.json"
        self.goals = []
        self.state = {}
        self.history = []
        self.need_engine = UnknownNeedEngine()

        self.memory_file.parent.mkdir(parents=True, exist_ok=True)
        self.load_memory()

        if initial_goal:
            self.set_goal(initial_goal)

        self.save_memory()
        print(f"[AGENT {self.agent_id}] Initialized with memory at {self.memory_file}")

    def load_memory(self):
        """Load persistent memory"""
        try:
            if self.memory_file.exists():
                with open(self.memory_file, 'r') as f:
                    data = json.load(f)
                    self.goals = data.get('goals', [])
                    self.state = data.get('state', {})
                    self.history = data.get('history', [])
            else:
                self.goals = []
                self.state = {}
                self.history = []
        except Exception as e:
            self.goals = []
            self.state = {}
            self.history = []

    def save_memory(self):
        """Save persistent memory"""
        try:
            data = {
                'goals': self.goals,
                'state': self.state,
                'history': self.history,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.memory_file, 'w') as f:
                json.dump(data, f, indent=2)
            sys.stdout.flush()
        except Exception as e:
            print(f"[AGENT {self.agent_id}] Error saving memory: {e}", file=sys.stderr)

    def set_goal(self, goal_description, priority=1):
        """Set a new autonomous goal uniquely (no duplicates)"""
        if any(g['description'] == goal_description and g['status'] == 'active' for g in self.goals):
            return

        goal = {
            'id': len(self.goals),
            'description': goal_description,
            'priority': priority,
            'status': 'active',
            'created': datetime.now().isoformat()
        }
        self.goals.append(goal)
        self.save_memory()
        print(f"[AGENT {self.agent_id}] Set new goal: {goal_description}")
        return goal

    def update_telemetry(self):
        """Read actual system health stats from the OS"""
        total, used, free = shutil.disk_usage(os.path.expanduser("~"))
        disk_pct = round((used / total) * 100, 2)
        try:
            load_1, load_5, load_15 = os.getloadavg()
        except AttributeError:
            load_1, load_5, load_15 = 0.0, 0.0, 0.0

        self.state = {
            "telemetry": {
                "disk_usage_pct": disk_pct,
                "disk_free_gb": round(free / (2**30), 2),
                "system_load_1m": load_1,
                "timestamp": datetime.now().isoformat()
            }
        }

    def process_goals(self):
        """Actively analyze current active goals with a strict 5-second timeout safeguard"""
        active_goals = [g for g in self.goals if g['status'] == 'active']
        for goal in active_goals:
            desc = goal['description']
            print(f"[AGENT {self.agent_id}] Evaluating active goal: \"{desc}\"")
            
            analysis = "⚠️ Analysis timed out or hung."
            # Force a strict 5-second timeout on the engine suggestion call
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(self.need_engine.suggest, desc)
                try:
                    analysis = future.result(timeout=60)
                except concurrent.futures.TimeoutError:
                    print(f"[AGENT {self.agent_id}] WARNING: Need engine hung on goal evaluation. Proceeding.")

            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "goal_id": goal['id'],
                "action": "evaluate_dependencies",
                "telemetry_at_execution": self.state.get("telemetry", {}),
                "gemini_analysis": analysis
            }
            self.history.append(log_entry)
            if len(self.history) > 15:
                self.history.pop(0)
            
            # ModMind Dashboard Hook: Export the latest clean insights
            insight_file = self.memory_file.parent / f"{self.agent_id}_latest_insights.json"
            with open(insight_file, 'w') as f_out:
                json.dump({"goal": desc, "suggestions": analysis, "updated": datetime.now().isoformat()}, f_out, indent=2)
            print(f"[AGENT {self.agent_id}] Logged evaluation.")

    def run(self):
        """Main active agent execution loop"""
        print(f"[AGENT {self.agent_id}] Starting main loop...")
        self.update_telemetry()
        self.process_goals()
        self.save_memory()
        try:
            while True:
                time.sleep(30)
                print(f"[AGENT {self.agent_id}] Executing cycle at {datetime.now()}")
                self.update_telemetry()
                self.process_goals()
                self.save_memory()
        except KeyboardInterrupt:
            self.save_memory()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(1)
    agent_id = sys.argv[1]
    initial_goal = sys.argv[2] if len(sys.argv) > 2 else None
    try:
        agent = VolitionCore(agent_id, initial_goal)
        agent.run()
    except Exception as e:
        sys.exit(1)
