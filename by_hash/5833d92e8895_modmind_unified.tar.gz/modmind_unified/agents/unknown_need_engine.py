#!/usr/bin/env python3
"""
Unknown Need Engine - Dynamically suggests hidden tools/prerequisites via local Ollama
"""

import json
import urllib.request
import urllib.error

class UnknownNeedEngine:
    def __init__(self):
        # Point directly to your local Ollama instance
        self.api_url = "http://localhost:11434/api/generate"
        self.model_name = "qwen2.5-coder:1.5b"

    def suggest(self, goal):
        """Invoke local Ollama to analyze the goal's dependencies"""
        system_instructions = (
            "You are the ModMind Unknown Need Engine. The user has given a swarm agent a goal. "
            "Identify 2 to 3 hidden technical dependencies, architecture requirements, or monitoring tools "
            "they might need but forgot to consider. Be concise, no bs, bullet points only."
        )
        
        full_prompt = f"{system_instructions}\n\nGoal: {goal}"
        
        # Build the standard Ollama API JSON payload
        payload = {
            "model": self.model_name,
            "prompt": full_prompt,
            "stream": False,
            "options": {
                "temperature": 0.2,
                "num_ctx": 1024,
                "num_predict": 80,
                "num_thread": 4
            }
        }

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.api_url, 
                data=data, 
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            # Use a strict 4-second timeout so it never blocks the core loop
            with urllib.request.urlopen(req, timeout=90) as response:
                res_body = response.read().decode('utf-8')
                res_json = json.loads(res_body)
                output = res_json.get("response", "").strip()
                
                if output:
                    return f"\n💡 [Local Engine Analysis] Suggestions:\n{output}"
                return "🎯 No additional suggestions - engine returned empty context."
                
        except urllib.error.URLError as e:
            return f"⚠️ [Need Engine Alert] Cannot connect to local Ollama. Is it running? ({e.reason})"
        except Exception as e:
            return f"⚠️ [Need Engine Alert] Local lookup error: {str(e)}"

if __name__ == "__main__":
    engine = UnknownNeedEngine()
    print(engine.suggest("Maintain system stability"))
