import json
import time
import math
from pathlib import Path

class HebbianMemory:
    def __init__(self, agent_id):
        self.agent_id = agent_id
        self.mem_file = Path.home() / "modmind_unified" / "agents" / f"{agent_id}_synapses.json"
        self.synapses = self.load_synapses()

    def load_synapses(self):
        if self.mem_file.exists():
            return json.loads(self.mem_file.read_text())
        return {}

    def reinforce(self, concept):
        """Increase the weight of a concept (Heebian learning)."""
        if concept not in self.synapses:
            self.synapses[concept] = {"weight": 1.0, "last_fired": time.time()}
        else:
            self.synapses[concept]["weight"] += 1.0
            self.synapses[concept]["last_fired"] = time.time()
        self.save()

    def decay(self):
        """Apply passive decay to all synapses over time."""
        for concept in self.synapses:
            # Apply decay based on time passed
            delta = time.time() - self.synapses[concept]["last_fired"]
            self.synapses[concept]["weight"] *= math.exp(-0.01 * delta / 3600)
        self.save()

    def save(self):
        self.mem_file.write_text(json.dumps(self.synapses, indent=2))

    def get_top_concepts(self, n=5):
        return sorted(self.synapses.items(), key=lambda x: x[1]['weight'], reverse=True)[:n]
