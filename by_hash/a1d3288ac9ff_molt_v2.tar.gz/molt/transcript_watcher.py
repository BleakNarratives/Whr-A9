#!/usr/bin/env python3
"""
Transcript Watcher - Monitors BasicNote for TERMINAL TRANSCRIPT entries
Executes molt instructions automatically
"""

import time
import os
import re
import subprocess
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

class TranscriptWatcher:
    def __init__(self, notes_dir: str, molt_dir: str):
        self.notes_dir = Path(notes_dir)
        self.molt_dir = Path(molt_dir)
        self.processed_file = self.molt_dir / 'logs' / 'processed_transcripts.txt'
        self.processed = self._load_processed()
        self.queue = []
        self.max_concurrent = 1  # Prevent phone meltdown
        
    def _load_processed(self) -> set:
        """Load list of already processed transcript IDs"""
        if self.processed_file.exists():
            return set(self.processed_file.read_text().splitlines())
        return set()
    
    def _mark_processed(self, transcript_id: str):
        """Mark a transcript as processed"""
        self.processed.add(transcript_id)
        with open(self.processed_file, 'a') as f:
            f.write(f"{transcript_id}\n")
    
    def watch(self, interval: int = 10):
        """Main watch loop"""
        print(f"👀 Watching {self.notes_dir} for TERMINAL TRANSCRIPTS...")
        print(f"📝 Check interval: {interval}s")
        print(f"🔥 Max concurrent: {self.max_concurrent}")
        
        while True:
            try:
                self._scan_for_transcripts()
                self._process_queue()
                time.sleep(interval)
            except KeyboardInterrupt:
                print("\n🛑 Watcher stopped")
                break
            except Exception as e:
                print(f"⚠️  Error in watch loop: {e}")
                time.sleep(interval * 2)
    
    def _scan_for_transcripts(self):
        """Scan notes directory for new transcripts"""
        
        if not self.notes_dir.exists():
            return
        
        for note_file in self.notes_dir.glob("*.txt"):
            file_id = note_file.stem
            
            if file_id in self.processed:
                continue
            
            content = note_file.read_text(errors='ignore')
            
            if "TERMINAL TRANSCRIPT" in content or "FINAL GROWTH:" in content:
                transcript = self._parse_transcript(content, file_id)
                if transcript:
                    self.queue.append(transcript)
                    self._mark_processed(file_id)
                    print(f"📥 Queued: {transcript['title'][:50]}")
    
    def _parse_transcript(self, content: str, file_id: str) -> Optional[Dict]:
        """Parse transcript content to extract instructions"""
        
        # Extract FINAL GROWTH section
        if "FINAL GROWTH:" not in content:
            return None
        
        parts = content.split("FINAL GROWTH:")
        if len(parts) < 2:
            return None
        
        instruction_text = parts[1].split("📊")[0].strip()
        
        # Extract score if present
        score_match = re.search(r'Final Score:\s*([\d.]+)', content)
        score = float(score_match.group(1)) if score_match else 0.0
        
        # Extract seed/task if present
        seed_match = re.search(r'Seed:\s*(.+?)(?:\n|═)', content)
        seed = seed_match.group(1).strip() if seed_match else "Unknown task"
        
        return {
            'id': file_id,
            'timestamp': datetime.now().isoformat(),
            'seed': seed,
            'instruction': instruction_text,
            'score': score,
            'raw_content': content
        }
    
    def _process_queue(self):
        """Process queued transcripts"""
        
        if not self.queue:
            return
        
        # Only process one at a time to avoid overwhelming the phone
        if len(self.queue) > self.max_concurrent:
            transcript = self.queue.pop(0)  # FIFO
        else:
            transcript = self.queue[0]
            self.queue = self.queue[1:]
        
        print(f"\n⚙️  Processing: {transcript['seed'][:50]}")
        print(f"📊 Score: {transcript['score']:.2f}")
        
        self._execute_instruction(transcript)
    
    def _execute_instruction(self, transcript: Dict):
        """Execute the instruction from transcript"""
        
        instruction = transcript['instruction']
        
        # Parse instruction for actionable commands
        actions = self._parse_actions(instruction)
        
        if not actions:
            print("⚠️  No actionable commands found")
            self._log_transcript(transcript, "No actions")
            return
        
        for action in actions:
            print(f"  → {action['type']}: {action['description'][:60]}")
            
            try:
                result = self._execute_action(action)
                self._log_transcript(transcript, f"Success: {result}")
            except Exception as e:
                print(f"  ❌ Failed: {e}")
                self._log_transcript(transcript, f"Error: {e}")
    
    def _parse_actions(self, instruction: str) -> List[Dict]:
        """Parse instruction text for actionable commands"""
        
        actions = []
        lines = instruction.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # Code execution patterns
            if any(keyword in line.lower() for keyword in ['implement', 'create', 'write', 'develop', 'build']):
                actions.append({
                    'type': 'code',
                    'description': line,
                    'priority': 1
                })
            
            # Configuration patterns
            elif any(keyword in line.lower() for keyword in ['configure', 'set', 'update', 'change']):
                actions.append({
                    'type': 'config',
                    'description': line,
                    'priority': 2
                })
            
            # Documentation patterns
            elif any(keyword in line.lower() for keyword in ['document', 'record', 'log']):
                actions.append({
                    'type': 'document',
                    'description': line,
                    'priority': 3
                })
        
        return sorted(actions, key=lambda x: x['priority'])
    
    def _execute_action(self, action: Dict) -> str:
        """Execute a specific action"""
        
        if action['type'] == 'code':
            # Pass to molt for implementation
            return self._molt_implement(action['description'])
        
        elif action['type'] == 'config':
            # Direct configuration change
            return self._apply_config(action['description'])
        
        elif action['type'] == 'document':
            # Create documentation
            return self._create_docs(action['description'])
        
        return "Unknown action type"
    
    def _molt_implement(self, description: str) -> str:
        """Use molt to implement something"""
        
        cmd = [
            'python',
            str(self.molt_dir / 'molt.py'),
            description
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            timeout=300,
            cwd=str(self.molt_dir)
        )
        
        if result.returncode == 0:
            return "Implementation completed"
        else:
            raise Exception(result.stderr.decode())
    
    def _apply_config(self, description: str) -> str:
        """Apply configuration change"""
        # Placeholder - implement based on your needs
        return f"Config: {description}"
    
    def _create_docs(self, description: str) -> str:
        """Create documentation"""
        # Placeholder - implement based on your needs
        return f"Documented: {description}"
    
    def _log_transcript(self, transcript: Dict, result: str):
        """Log transcript processing result"""
        
        log_file = self.molt_dir / 'logs' / 'transcript_log.txt'
        
        with open(log_file, 'a') as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"Time: {transcript['timestamp']}\n")
            f.write(f"Seed: {transcript['seed']}\n")
            f.write(f"Score: {transcript['score']:.2f}\n")
            f.write(f"Result: {result}\n")


def main():
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python transcript_watcher.py <notes_directory>")
        print("\nExample:")
        print("  python transcript_watcher.py ~/storage/shared/BasicNote")
        sys.exit(1)
    
    notes_dir = sys.argv[1]
    molt_dir = Path(__file__).parent.parent
    
    watcher = TranscriptWatcher(notes_dir, molt_dir)
    watcher.watch()


if __name__ == '__main__':
    main()
