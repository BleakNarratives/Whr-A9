# MOLT v2 - Multi-Backend Recursive Improvement Engine

Runs on **Ollama + Mistral CLI + Gemini CLI** with automatic fallback when backends fail.

## New Features

### 🔄 Multi-Backend Support
- Tries Ollama first (fastest, local)
- Falls back to Mistral CLI if Ollama fails
- Falls back to Gemini CLI if both fail
- Automatically routes to the most reliable backend

### 👀 Transcript Watcher
- Monitors BasicNote for TERMINAL TRANSCRIPT entries
- Automatically executes molt instructions
- Queues tasks to prevent phone overload
- Logs all executions

### 📊 Health Monitoring
- Tracks backend failures
- Routes requests intelligently
- Self-heals when backends recover

## Setup

### 1. Install CLI Tools (Optional but Recommended)

```bash
# Mistral CLI
npm install -g @mistral-cli/cli

# Gemini CLI
npm install -g @google/gemini-cli
```

### 2. Run Setup

```bash
cd molt
chmod +x setup_cli.sh
./setup_cli.sh
```

This checks which backends are available.

### 3. Configure

Edit `config.json`:

```json
{
  "use_multi_backend": true,
  "mistral_enabled": true,
  "gemini_enabled": true,
  "ollama_host": "http://127.0.0.1:11434",
  "ollama_model": "deepseek-r1:1.5b"
}
```

## Usage

### Basic Molt (same as before)

```bash
python molt.py "your task"
```

Now it will automatically use whichever backend is working.

### Transcript Watcher

```bash
# Start watching BasicNote directory
python transcript_watcher.py ~/storage/shared/BasicNote

# Or wherever your notes are stored
```

The watcher will:
1. Scan for new TERMINAL TRANSCRIPT entries
2. Parse the FINAL GROWTH instructions
3. Execute them via molt
4. Log results

### Health Check

```bash
python << 'EOF'
from core.multi_backend import MultiBackend
import json

with open('config.json') as f:
    config = json.load(f)

backend = MultiBackend(config)
print(backend.health_check())
EOF
```

## How It Works

### Multi-Backend Flow

```
User Request
    ↓
Try Ollama (local, fast)
    ↓ (if fails)
Try Mistral CLI
    ↓ (if fails)
Try Gemini CLI
    ↓ (if fails)
Return error
```

### Transcript Watcher Flow

```
BasicNote Directory
    ↓
Scan for new .txt files
    ↓
Contains "TERMINAL TRANSCRIPT"?
    ↓
Parse FINAL GROWTH section
    ↓
Extract actionable commands
    ↓
Execute via molt
    ↓
Log results
```

## Architecture

```
molt/
├── molt.py              # Main entry (now with multi-backend)
├── transcript_watcher.py # BasicNote integration
├── setup_cli.sh         # CLI tools setup
├── core/
│   ├── multi_backend.py # Backend orchestration
│   ├── iterate.py       # Iteration engine
│   └── ollama_bridge.py # Ollama connection
├── memory/
│   └── improvements.py  # Storage system
└── logs/
    ├── processed_transcripts.txt
    └── transcript_log.txt
```

## Troubleshooting

### "All backends failed"

Check what's working:
```bash
./setup_cli.sh
```

At least ONE backend must be available.

### Transcript watcher not finding notes

Make sure path is correct:
```bash
ls ~/storage/shared/BasicNote/*.txt
```

### Ollama timeouts

This is normal - the multi-backend will automatically try Mistral/Gemini instead.

## What This Enables

1. **Resilience** - If Ollama is slow/down, other models take over
2. **Automation** - Transcript watcher executes molt output automatically
3. **Scalability** - Can add more backends easily
4. **Distributed** - Ready for P2P molt network (coming soon)

## Next Steps

- [ ] P2P molt network (share compute with other nodes)
- [ ] Code City visualization integration
- [ ] The Obelisk (boardroom view)
- [ ] Resource optimizer (storage cleanup)
- [ ] Auto-shipper (deploy projects automatically)

---

Built to run on a phone in a bathroom. Fuck the cloud.
