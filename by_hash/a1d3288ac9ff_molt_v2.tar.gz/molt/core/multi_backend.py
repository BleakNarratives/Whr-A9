"""
Multi-Backend Orchestrator
Coordinates Ollama, Mistral CLI, and Gemini CLI
Falls back when one fails
"""

import subprocess
import json
import time
from typing import Optional, Dict, List
import requests

class MultiBackend:
    def __init__(self, config: Dict):
        self.config = config
        self.backends = ['ollama', 'mistral', 'gemini']
        self.failure_counts = {b: 0 for b in self.backends}
        self.last_success = None
        
    def generate(self, prompt: str, system: Optional[str] = None, max_retries: int = 3) -> str:
        """Try backends in order until one works"""
        
        # Start with last successful backend
        if self.last_success:
            backends = [self.last_success] + [b for b in self.backends if b != self.last_success]
        else:
            backends = self.backends
        
        for backend in backends:
            for attempt in range(max_retries):
                try:
                    result = self._call_backend(backend, prompt, system)
                    if result and len(result) > 10:  # Valid response
                        self.last_success = backend
                        self.failure_counts[backend] = 0
                        return result
                except Exception as e:
                    print(f"[{backend}] Attempt {attempt + 1} failed: {e}")
                    time.sleep(2 ** attempt)  # Exponential backoff
            
            self.failure_counts[backend] += 1
        
        return "Error: All backends failed"
    
    def _call_backend(self, backend: str, prompt: str, system: Optional[str]) -> str:
        """Call specific backend"""
        
        if backend == 'ollama':
            return self._call_ollama(prompt, system)
        elif backend == 'mistral':
            return self._call_mistral_cli(prompt, system)
        elif backend == 'gemini':
            return self._call_gemini_cli(prompt, system)
        
        raise ValueError(f"Unknown backend: {backend}")
    
    def _call_ollama(self, prompt: str, system: Optional[str]) -> str:
        """Call Ollama API"""
        host = self.config.get('ollama_host', 'http://127.0.0.1:11434')
        model = self.config.get('ollama_model', 'deepseek-r1:1.5b')
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 1024
            }
        }
        
        if system:
            payload["system"] = system
        
        response = requests.post(
            f"{host}/api/generate",
            json=payload,
            timeout=180
        )
        response.raise_for_status()
        return response.json().get('response', '')
    
    def _call_mistral_cli(self, prompt: str, system: Optional[str]) -> str:
        """Call Mistral CLI (piping via stdin)"""
        
        # Combine system and prompt
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        
        # Check if mistral-cli is available
        check = subprocess.run(['which', 'mistral-cli'], capture_output=True)
        if check.returncode != 0:
            raise Exception("mistral-cli not found in PATH")
        
        # Call via subprocess
        result = subprocess.run(
            ['mistral-cli', '--no-stream'],
            input=full_prompt.encode(),
            capture_output=True,
            timeout=120
        )
        
        if result.returncode != 0:
            raise Exception(f"mistral-cli error: {result.stderr.decode()}")
        
        return result.stdout.decode().strip()
    
    def _call_gemini_cli(self, prompt: str, system: Optional[str]) -> str:
        """Call Gemini CLI"""
        
        # Combine system and prompt
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        
        # Check if gemini is available
        check = subprocess.run(['which', 'gemini'], capture_output=True)
        if check.returncode != 0:
            raise Exception("gemini CLI not found in PATH")
        
        # Call via subprocess
        result = subprocess.run(
            ['gemini', 'generate', '--text', full_prompt],
            capture_output=True,
            timeout=120
        )
        
        if result.returncode != 0:
            raise Exception(f"gemini error: {result.stderr.decode()}")
        
        return result.stdout.decode().strip()
    
    def health_check(self) -> Dict[str, bool]:
        """Check which backends are working"""
        health = {}
        
        for backend in self.backends:
            try:
                result = self._call_backend(backend, "say OK", None)
                health[backend] = bool(result and len(result) > 0)
            except:
                health[backend] = False
        
        return health
    
    def get_best_backend(self) -> str:
        """Return backend with lowest failure count"""
        return min(self.failure_counts, key=self.failure_counts.get)
