#!/bin/bash

# Setup script for Mistral and Gemini CLI integration

echo "🔧 Setting up CLI integrations..."

# Check for Mistral CLI
if command -v mistral-cli &> /dev/null; then
    echo "✅ Mistral CLI found"
else
    echo "⚠️  Mistral CLI not found"
    echo "   Install with: npm install -g @mistral-cli/cli"
fi

# Check for Gemini CLI  
if command -v gemini &> /dev/null; then
    echo "✅ Gemini CLI found"
else
    echo "⚠️  Gemini CLI not found"
    echo "   Install with: npm install -g @google/gemini-cli"
fi

# Check for Ollama
if curl -s http://127.0.0.1:11434/api/tags > /dev/null 2>&1; then
    echo "✅ Ollama running"
else
    echo "⚠️  Ollama not responding"
    echo "   Start with: ollama serve"
fi

echo ""
echo "Testing backends..."
python3 << 'EOF'
from core.multi_backend import MultiBackend
import json

with open('config.json') as f:
    config = json.load(f)

backend = MultiBackend(config)
health = backend.health_check()

print("\nBackend Health:")
for name, status in health.items():
    icon = "✅" if status else "❌"
    print(f"  {icon} {name}")

if any(health.values()):
    print("\n🌱 At least one backend is working - molt is ready!")
else:
    print("\n⚠️  No backends available")
EOF
